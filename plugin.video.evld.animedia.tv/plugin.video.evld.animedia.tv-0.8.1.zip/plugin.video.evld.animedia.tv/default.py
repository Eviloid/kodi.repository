#!/usr/bin/python
# -*- coding: utf-8 -*-
# Eviloid, 08.12.2019

import os, urllib, sys, urllib2, re, json
import urlparse as parse

import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import CommonFunctions

from random import randrange

PLUGIN_NAME = 'AniMedia.TV Online'

common = CommonFunctions
common.plugin = PLUGIN_NAME

try:handle = int(sys.argv[1])
except:pass

addon = xbmcaddon.Addon(id='plugin.video.evld.animedia.tv')

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(Pdir, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(Pdir, 'fanart.jpg'))

xbmcplugin.setContent(handle, 'tvshows')

BASE_URL = 'https://%s' % addon.getSetting('host')

def get_html(url, params=None, post=None, headers={}):
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'

    if params:
        url = '%s?%s' % (url, urllib.urlencode(params))

    if post:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        request = urllib2.Request(url, urllib.urlencode(post), headers=headers)
    else:
        request = urllib2.Request(url, headers=headers)

    conn = urllib2.urlopen(request)
    html = conn.read()
    conn.close()

    return html 


def main_menu(params):
    if params.get('p', 0) == 0:
        add_item('[B]Популярные[/B]', params={'mode':'popular'}, fanart=fanart, isFolder=True)
        add_item('[B]Поиск[/B]', params={'mode':'find'}, fanart=fanart, icon='DefaultAddonsSearch.png', isFolder=True)

    show_catalogue(params)


def show_catalogue(params):

    query = {'limit': 20}

    query['orderby_sort'] = 'view_count_one|desc' if params['mode'] == 'popular' else 'entry_date|desc'

    keywords = params.get('keywords')
    if keywords:
        query['keywords'] = urllib.unquote_plus(keywords)

    page = int(params.get('p', 0))

    html = get_html('%s/ajax/search_result_search_page_2/P%s' % (BASE_URL, page * 20), params=query)

    videos = common.parseDOM(html, 'div', attrs={'class':'ads-list__item'})
    if videos:
        for video in videos:
            img = common.parseDOM(video, 'img', ret='data-src')[0]
            img = '%s?w=512' % img.split('?')[0]

            title = common.replaceHTMLCodes(common.parseDOM(video, 'a', attrs={'class':'h3 ads-list__item__title'})[0])
            original = common.replaceHTMLCodes(common.parseDOM(video, 'div', attrs={'class':'original-title'})[0])
            rate =  common.parseDOM(video, 'div', attrs={'class':'raitings'})[0]

            tags = common.parseDOM(video, 'div', attrs={'class':'genre-tags'})
            genres = ', '.join(common.parseDOM(tags, 'a'))

            plot = u'[B]%s[/B] [COLOR=gray]\u2022 %s[/COLOR]\n\nРейтинг: [COLOR=yellow]%s[/COLOR]\nЖанр: [COLOR=darkcyan]%s[/COLOR]' % (title, original, rate, genres)

            url = common.parseDOM(video, 'a', attrs={'class':'overlay__counters__primary__wrap'}, ret='href')[0].encode('utf-8')
            add_item(title, {'mode':'seasons', 'u':url}, thumb=img, fanart=fanart, plot=plot, isFolder=True)

    pagination = common.parseDOM(html, 'div', attrs={'class':'paginate'})
    if pagination:
        params['p'] = page + 1
        add_item('Далее > %i' % (params['p'] + 1), params, fanart=fanart, isFolder=True)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)


def do_find(params):
    keywords = ''

    kbd = xbmc.Keyboard('', 'Поиск:')
    kbd.doModal()
    if kbd.isConfirmed():
        keywords = kbd.getText()

    if keywords:
        params['keywords'] = keywords
        params['mode'] = 'popular'
        show_catalogue(params)


def show_seasons(params):
    url = '%s%s' % (BASE_URL, urllib.unquote_plus(params['u']))

    html = get_html(url)

    try:
        serial_id = common.parseDOM(html, 'ul', attrs={'role':'tablist'}, ret='data-entry_id')[0]
    except:
        xbmcplugin.endOfDirectory(handle)
        return

    container = common.parseDOM(html, 'div', attrs={'class':'widget__post-info__poster'})
    img = common.parseDOM(container, 'a', ret='href')[0]
    img = '%s?w=512' % img.split('?')[0]

    container = common.parseDOM(html, 'div', attrs={'class':'media__sshots'})
    if container:
        screens = common.parseDOM(container, 'a', ret='href')
        fan = screens[randrange(len(screens))].split('?')[0]
    else:
        fan = fanart

    plot = common.stripTags(common.replaceHTMLCodes(common.parseDOM(html, 'div', attrs={'class':'media__post__body'})[0]))

    container = common.parseDOM(html, 'ul', attrs={'role':'tablist'})
    groups = common.parseDOM(container, 'a')
    hrefs = common.parseDOM(container, 'a', ret='href')

    for i, g in enumerate(groups):
        group = int(hrefs[i][4:]) + 1
        add_item(g, {'mode':'series', 'id':serial_id, 'g':group}, thumb=img, fanart=fan, plot=plot, isFolder=True)

    if addon.getSetting('ShowTorrents') == 'true':
        torrent = common.parseDOM(html, 'a', attrs={'class':'btn btn__big btn__green btn__dowload-torrent'}, ret='href')
        if torrent:
            add_item('[B]Торренты[/B]', {'mode':'torrents', 'u':torrent[0]}, thumb=img, fanart=fan, plot=plot, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def show_series(params):
    serial_id = params.get('id')
    group = params.get('g', 1)

    html = get_html('%s/ajax/episodes/%s/%s/undefined' % (BASE_URL, serial_id, group))

    series = common.parseDOM(html, 'div', attrs={'class':'media__tabs__series__list__item'})

    for s in series:
        title = common.parseDOM(s, 'a', ret='title')[0]
        url = common.parseDOM(s, 'a', ret='href')[0].encode('utf-8')
        img = common.parseDOM(s, 'img', ret='data-src')[0].replace('_min.', '.')
        img = 'https:%s?w=512' % img.split('?')[0]

        add_item(title, {'mode':'play', 'u':url}, thumb=img, fanart=fanart, isPlayable=True)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)


def show_torrents(params):
    url = urllib.unquote_plus(params['u'])
    html = get_html(BASE_URL + url)
    url = common.parseDOM(html, 'a', attrs={'class':'btn__help__to__project'}, ret='href')[0]
    html = get_html(url)

    container = common.parseDOM(html, 'div', attrs={'class':'widget__post-info__poster'})
    img = common.parseDOM(container, 'a', ret='href')[0]
    img = '%s?w=512' % img.split('?')[0]

    container = common.parseDOM(html, 'div', attrs={'class':'media__sshots'})
    if container:
        screens = common.parseDOM(container, 'a', ret='href')
        fan = screens[randrange(len(screens))].split('?')[0]
    else:
        fan = fanart

    container = common.parseDOM(html, 'ul', attrs={'role':'tablist'})
    if container:
        groups = common.parseDOM(container, 'a')
        hrefs = common.parseDOM(container, 'a', ret='href')

        for i, g in enumerate(groups):
            container = common.parseDOM(html, 'div', attrs={'id':hrefs[i][1:]})
            torrents = common.parseDOM(container, 'div', attrs={'class':'tracker_info'})

            for t in torrents:
                t = re.sub('<!--(.*?)-->', '', t)
                title = '[COLOR=yellow]%s[/COLOR] %s' % (g, common.parseDOM(t, 'h3', attrs={'class':'tracker_info_bold'})[0])

                plot = ''
                plots = common.parseDOM(t, 'div', attrs={'class':'releases-track'})
                for p in plots:
                    plot = '%s%s\n' % (plot, common.stripTags(p))

                url = common.parseDOM(t, 'a', attrs={'class':'btn btn__green btn__magnet'}, ret='href')
                if url:
                    add_item(title, {'mode':'magnet', 'u':url[0]}, thumb=img, fanart=fan, plot=plot, isFolder=True)

    else:
        torrents = common.parseDOM(html, 'div', attrs={'class':'input_block'})
        for t in torrents:
            t = re.sub('<!--(.*?)-->', '', t)
            title = common.parseDOM(t, 'span', attrs={'class':'intup_left_top'})[0]
            plot = ''
            plots = common.parseDOM(t, 'span', attrs={'class':'intup_left_op'})
            for p in plots:
                plot = plot + common.stripTags(p)

            url = common.parseDOM(t, 'a', attrs={'class':'download_tracker_btn_input'}, ret='href')

            if url:
                add_item(title, {'mode':'magnet', 'u':url[0]}, thumb=img, fanart=fan, plot=plot.replace(';', '\n'), isFolder=True)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)


def show_magnet(params):
    uri = urllib.unquote_plus(params['u'])

    torrent = get_html(uri)

    import bencode

    torrent = bencode.bdecode(torrent)

    items = []

    files = torrent['info'].get('files', None)

    if files == None:
        title = '{0} ({1} MB)'.format(torrent['info']['name'], torrent['info']['length'] / 1024 / 1024)
        items.append({'title':title, 'id':0})
    else:
        for i, f in enumerate(files):
            title = '{0} ({1} MB)'.format(f['path'][-1], f['length'] / 1024 / 1024)
            items.append({'title':title, 'id':i})
        items = sorted(items, key=lambda x: x['title'])

    for i, item in enumerate(items):
        add_item(item['title'], {'mode':'play','u':uri,'i':i,'o':item['id']}, icon=icon, fanart=fanart, isPlayable=True, isFolder=False)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)


def parse_pladform(url, play=False):
    info = {'title':'Видео недоступно','thumb':'', 'url':''}

    html = get_html(url)

    iframe = re.search(r'iframe src=["\'](.*?)["\']', html)
    if iframe:
        if 'pladform.ru' in iframe.group(1):
            html = get_html(re.sub(r'^//', 'https://', iframe.group(1)))
            poster = re.search(r"poster.*=.*'(.*?)'", html)
            title = re.search(r"title.*=.*'(.*?)'", html)
            flashvars = re.search(r"flashvars.*=.*'(.*?)'", html)

            info['thumb'] = poster.group(1)

            uri = 'https://out.pladform.ru/getVideo?target=web-html5' + flashvars.group(1).replace('&video=', '&videoid=')
            html = get_html(uri)
            hls = re.search(r'type="hls"><!\[CDATA\[(.*?)\]', html)

            if hls:
                info['url'] = hls.group(1)
                info['title'] = title.group(1)

    return info


def parse_kodik(html):
    s = re.search(r'kodikAddPlayers = ({.*?});', html, re.MULTILINE | re.DOTALL)
    if s:
        a = s.group(1).replace(r"'", r'"')

        a = re.sub(r'([^\w\"\.])(\w+)\s*:', r'\1"\2":', a)
        a = re.sub(r'("\w+")\s*:\s*([\w\.]+)', r'\1:"\2"', a)
        a = re.sub(r'("\w+")\s*:\s*\[([\w\.]+)\]', r'\1:"\2"', a)
        a = re.sub(r'(,\s*)(})', r'\2', a)

        params = json.loads(a)

        js = get_html('https://kodik-add.com/add-players.min.js')
        token = re.search(r'r.token="(\S*)"', js).group(1)

        params.update({'token':token, 'hasPlayer':False})

        data = get_html('https://kodikapi.com/get-player', params=params)

        data = json.loads(data)

        if data['found']:
            iframe = re.sub(r'^//', 'https://', data['link'])
            host = parse.urlsplit(iframe).netloc
            iframe = '%s?translations=%s' % (iframe, 'AniDUB')

            html = get_html(iframe, headers={'Referer':BASE_URL})

            container = common.parseDOM(html, 'div', attrs={'class':'series-options'})
            urls = common.parseDOM(container, 'option', attrs={'data-num':params['episode']}, ret='value')

            if urls:
                seria_url = re.sub(r'^//', 'https://', urls[0])
                video_id, video_hash = seria_url.split('/')[5:7]

                params = dict(parse.parse_qsl(parse.urlsplit(seria_url).query))
                params.update({'type': 'seria', 'id': video_id, 'hash': video_hash, 'hash2': 'vbWENyTwIn8I'})

                data = get_html('https://%s/video-getter' % host, post=params)
                data = json.loads(data)

                return re.sub(r'^//', 'https://', data['links']['720'][0]['src'])

    return None


def play_video(params):
    id = int(params.get('i', -1))

    if id >= 0:
        uri = urllib.unquote_plus(params['u'])
        torrent = get_html(uri)

        preload_size = int(addon.getSetting('Preload'))

        import player

        if addon.getSetting('Engine') == '1':
            player.play_ts(handle, preload_size, addon.getSetting('TSHost'), addon.getSetting('TSPort'), torrent, id)
        else:
            oid = int(params.get('o'))
            temp_name = os.path.join(xbmc.translatePath('special://masterprofile'), 'ani.torrent')

            temp_file = open(temp_name.decode('utf-8') if sys.platform == 'win32' else temp_name, 'wb')
            temp_file.write(torrent)
            temp_file.close()

            if addon.getSetting('Engine') == '2':
                purl ='plugin://plugin.video.elementum/play?uri='+ urllib.quote_plus(temp_name) + '&index={0}&oindex={1}'.format(id, oid)
                item = xbmcgui.ListItem(path=purl)
                xbmcplugin.setResolvedUrl(handle, True, item)
            else:
                uri = 'file:///' + temp_name.replace('\\', '/')
                player.play_t2h(handle, preload_size, uri, oid)

        return


    url = '%s%s' % (BASE_URL, urllib.unquote_plus(params['u']))
    html = get_html(url)

    title = common.parseDOM(html, 'h1', attrs={'class':'media__post__title'})[0].replace(u' Смотреть онлайн', '')

    video = re.search(r'<video src="(.*?)"', html)

    if video:
        purl = video.group(1)
    else:
        embed = common.parseDOM(html, 'meta', attrs={'property':'og:video:iframe'}, ret='content')[0]

        iframe = get_html(embed)
        match = re.findall(r'file: "(.+?)"', iframe)

        if match:
            purl = match[0]

            urls = re.findall(r'(?:\[(.+?)\](.+?\.(?:mp4|m3u8)))+', purl)
            if urls:
                purl = urls[-1][1]

    purl = re.sub(r'^//', 'https://', purl)

    if urllib.urlopen(purl).getcode() != 200:
        purl = parse_kodik(html)

    if purl:
        if urllib.urlopen(purl).getcode() != 200:
            info = parse_pladform(url)
            purl = info['url']
            title = info['title']

    if purl:
        item = xbmcgui.ListItem(path=purl)
        item.setInfo(type='video', infoLabels={'title':title})

        if addon.getSetting('UseStreamAdaptive') == 'true' and not '.mp4' in purl:
            item.setProperty('inputstreamaddon', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')

        xbmcplugin.setResolvedUrl(handle, True, item)


def add_item(title, params={}, icon='', banner='', fanart='', poster='', thumb='', plot='', isFolder=False, isPlayable=False, url=None):
    item = xbmcgui.ListItem(title, iconImage=icon, thumbnailImage=thumb)
    item.setInfo(type='video', infoLabels={'title': title, 'plot': plot})

    if isPlayable:
        item.setProperty('isPlayable', 'true')
        item.setProperty('mediatype', 'video')

    if banner != '':
        item.setArt({'banner': banner})
    if fanart != '':
        item.setArt({'fanart': fanart})
    if poster != '':
        item.setArt({'poster': poster})
    if thumb != '':
        item.setArt({'thumb': thumb})

    if url is None:
        url = '%s?%s' % (sys.argv[0], urllib.urlencode(params))
        item.setContentLookup(False)

    xbmcplugin.addDirectoryItem(handle, url=url, listitem=item, isFolder=isFolder)


def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()

mode = params['mode'] = params.get('mode', '')

if mode == '':
    main_menu(params)

elif mode == 'popular':
    show_catalogue(params)

elif mode == 'find':
    do_find(params)

elif mode == 'seasons':
    show_seasons(params)

elif mode == 'series':
    show_series(params)

elif mode == 'torrents':
    show_torrents(params)

elif mode == 'magnet':
    show_magnet(params)

elif mode == 'play':
    play_video(params)

elif mode == 'cleancache':
    from tccleaner import TextureCacheCleaner as tcc
    tcc().remove_like('%animedia%', True)
