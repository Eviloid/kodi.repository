#!/usr/bin/python
# -*- coding: utf-8 -*-
# Eviloid, 08.12.2019

import os, urllib, sys, urllib2, re, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import CommonFunctions

from random import randrange

PLUGIN_NAME   = 'AniMedia.TV Online'
BASE_URL = 'https://online.animedia.tv'


common = CommonFunctions
common.plugin = PLUGIN_NAME


try:handle = int(sys.argv[1])
except:pass

addon = xbmcaddon.Addon(id='plugin.video.evld.animedia.tv')

Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(Pdir, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(Pdir, 'fanart.jpg'))

xbmcplugin.setContent(handle, 'tvshows')

def get_html(url, headers = {}, post = None):

    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'

    if post:
        conn = urllib2.urlopen(urllib2.Request(url, urllib.urlencode(post), headers=headers))
    else:
        conn = urllib2.urlopen(urllib2.Request(url, headers=headers))

    html = conn.read()
    conn.close()

    return html


def main_menu(params):
    if params.get('p', 0) == 0:
        add_item('[B]Популярные[/B]', params={'mode':'popular'}, fanart=fanart, isFolder=True)
        add_item('[B]Поиск[/B]', params={'mode':'find'}, fanart=fanart, icon='DefaultAddonsSearch.png', isFolder=True)

    show_catalogue(params)


def show_catalogue(params):

    if params['mode'] == 'popular':
        order = '&orderby=view_count_one+desc'
    else:
        order = '&orderby=entry_date+desc'

    keywords = params.get('keywords')
    keywords = '&keywords=%s' % keywords if keywords else '' 

    page = int(params.get('p', 0))

    html = get_html('%s/ajax/search_result_search_page_2/P%ssearch&limit=20%s%s' % (BASE_URL, page * 20, order, keywords))

    videos = common.parseDOM(html, 'div', attrs={'class':'ads-list__item'})
    if videos:
        for video in videos:
            img = common.parseDOM(video, 'img', ret='data-src')[0]
            img = '%s?w=512' % img.split('?')[0]

            title = common.replaceHTMLCodes(common.parseDOM(video, 'a', attrs={'class':'h3 ads-list__item__title'})[0])
            original =  common.replaceHTMLCodes(common.parseDOM(video, 'div', attrs={'class':'original-title'})[0])
            rate =  common.parseDOM(video, 'div', attrs={'class':'raitings'})[0]
            
            plot = u'[B]%s[/B] [COLOR=gray]\u2022 %s[/COLOR]\nРейтинг: [COLOR=yellow]%s[/COLOR]' % (title, original, rate)   

            url = common.parseDOM(video, 'a', attrs={'class':'overlay__counters__primary__wrap'}, ret='href')[0].encode('utf-8')
            add_item(title, {'mode':'seasons', 'u':url}, thumb=img, fanart=fanart, plot=plot, isFolder=True)

    pagination = common.parseDOM(html, 'div', attrs={'class':'paginate'})
    if pagination:
        params['p'] = page + 1
        add_item('Далее > %i' % (params['p'] + 1), params, fanart=fanart, isFolder=True)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)


def do_find(params):
    keywords = ''

    kbd = xbmc.Keyboard('', 'Поиск:')
    kbd.doModal()
    if kbd.isConfirmed():
        keywords = kbd.getText()

    if keywords:
        params['keywords'] = keywords
        params['mode'] = 'popular'
        show_catalogue(params)


def show_seasons(params):
    url = urllib.unquote_plus(params['u'])

    html = get_html(url)

    try:
        serial_id = common.parseDOM(html, 'ul', attrs={'role':'tablist'}, ret='data-entry_id')[0]
    except:
        xbmcplugin.endOfDirectory(handle)
        return

    container = common.parseDOM(html, 'div', attrs={'class':'widget__post-info__poster'})
    img = common.parseDOM(container, 'a', ret='href')[0]
    img = '%s?w=512' % img.split('?')[0]

    container = common.parseDOM(html, 'div', attrs={'class':'media__sshots'})
    if container:
        screens = common.parseDOM(container, 'a', ret='href')
        fan = screens[randrange(len(screens))].split('?')[0]
    else:
        fan = fanart

    plot = common.stripTags(common.replaceHTMLCodes(common.parseDOM(html, 'div', attrs={'class':'media__post__body'})[0]))

    container = common.parseDOM(html, 'ul', attrs={'role':'tablist'})
    groups = common.parseDOM(container, 'a')
    hrefs = common.parseDOM(container, 'a', ret='href')

    for i, g in enumerate(groups):
        group = int(hrefs[i][4:]) + 1
        add_item(g, {'mode':'series', 'id':serial_id, 'g':group}, thumb=img, fanart=fan, plot=plot, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def show_series(params):
    serial_id = params.get('id')
    group = params.get('g', 1)

    html = get_html('%s/ajax/episodes/%s/%s' % (BASE_URL, serial_id, group))

    series = common.parseDOM(html, 'div', attrs={'class':'media__tabs__series__list__item'})

    for s in series:
        title = common.parseDOM(s, 'a', ret='title')[0]
        url = common.parseDOM(s, 'a', ret='href')[0].encode('utf-8')
        img = common.parseDOM(s, 'img', ret='data-src')[0].replace('_min.', '.')
        img = 'https:%s?w=512' % img.split('?')[0]

        add_item(title, {'mode':'play', 'u':url}, thumb=img, fanart=fanart, isPlayable=True)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)


def parse_pladform(url, play=False):
    info = {'title':'Видео недоступно','thumb':'', 'url':''}

    html = get_html(url)

    iframe = re.search(r'iframe src=["\'](.*?)["\']', html)
    if iframe:
        if 'pladform.ru' in iframe.group(1):
            html = get_html('https:' + iframe.group(1))
            poster = re.search(r"poster.*=.*'(.*?)'", html)
            title  = re.search(r"title.*=.*'(.*?)'", html)
            flashvars  = re.search(r"flashvars.*=.*'(.*?)'", html)

            info['thumb'] = poster.group(1)

            uri = 'https://out.pladform.ru/getVideo?target=web-html5' + flashvars.group(1).replace('&video=', '&videoid=')
            html = get_html(uri)
            hls  = re.search(r'type="hls"><!\[CDATA\[(.*?)\]', html)

            if hls:
                info['url'] = hls.group(1)
                info['title'] = title.group(1)

    return info


def play_video(params):
    url = '%s%s' % (BASE_URL, urllib.unquote_plus(params['u']))
    html = get_html(url)

    embed = common.parseDOM(html, 'meta', attrs={'property':'og:video:iframe'}, ret='content')[0]
    title = common.parseDOM(html, 'h1', attrs={'class':'media__post__title'})[0].replace(u' Смотреть онлайн', '')

    iframe = get_html(embed)
    match = re.compile(r'file: "(.+?)"').findall(iframe)

    if match:
        purl = match[0]

        if purl[:4] != 'http':
            purl = 'https:' + purl

        if urllib.urlopen(purl).getcode() != 200:
            info = parse_pladform(url)
            purl = info['url']
            title = info['title']

        if purl:
            item = xbmcgui.ListItem(path=purl)
            item.setInfo(type='video', infoLabels={'title':title})

            if addon.getSetting('UseStreamAdaptive') == 'true':
                item.setProperty('inputstreamaddon', 'inputstream.adaptive')
                item.setProperty('inputstream.adaptive.manifest_type', 'hls')

            xbmcplugin.setResolvedUrl(handle, True, item)


def add_item(title, params={}, icon='', banner='', fanart='', poster='', thumb='', plot='', isFolder=False, isPlayable=False, url=None):
    if url == None: url = '%s?%s' % (sys.argv[0], urllib.urlencode(params))

    item = xbmcgui.ListItem(title, iconImage = icon, thumbnailImage = thumb)
    item.setInfo(type='video', infoLabels={'title': title, 'plot': plot})

    if isPlayable:
        item.setProperty('isPlayable', 'true')
        item.setProperty('mediatype', 'video')
    
    if banner != '':
        item.setArt({'banner': banner})
    if fanart != '':
        item.setArt({'fanart': fanart})
    if poster != '':
        item.setArt({'poster': poster})
    if thumb != '':
        item.setArt({'thumb': thumb})

    xbmcplugin.addDirectoryItem(handle, url=url, listitem=item, isFolder=isFolder)


def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()

mode = params['mode'] = params.get('mode', '')

if mode == '':
    main_menu(params)

elif mode == 'popular':
    show_catalogue(params)

elif mode == 'find':
    do_find(params)

elif mode == 'seasons':
    show_seasons(params)

elif mode == 'series':
    show_series(params)

elif mode == 'play':
    play_video(params)

elif mode == 'cleancache':
    from tccleaner import TextureCacheCleaner as tcc
    tcc().remove_like('%animedia%', True)
