# -*- coding: utf-8 -*-

import os, urllib, urllib2, json, time, binascii
from io import BytesIO


class Engine(object):

    def __init__(self, host='127.0.0.1', port=8090):
        self.host = host
        self.port = port
        self.success = True
        self.version = None
        self.hash = None
        self._preload_size = 20
        self._index = 0

        if not self.echo():
            self.success = False
            return

    @property
    def url(self):
        return self._get_url()

    def make_url(self, path):
        return 'http://' + self.host + ':' + str(self.port) + path

    def encode_multipart_formdata(self, data):
        body = BytesIO()
        boundary = binascii.hexlify(os.urandom(16))

        body.write("--%s\r\n" % boundary)
        body.write("Content-Disposition: form-data; name=\"file\"; filename=shiza.torrent\r\n")
        body.write("Content-Type: application/octet-stream\r\n")
        body.write("\r\n")
        body.write(data)
        body.write("\r\n")
        body.write("--%s--\r\n" % boundary)

        content_type = "multipart/form-data; boundary=%s" % boundary
        return body.getvalue(), content_type

    def request(self, name, data=None, is_file=False):
        url = self.make_url('/torrent/' + name)

        headers = {'Content-Type':'application/json'}

        if is_file and data:
            data, content_type = self.encode_multipart_formdata(data)
            headers = {'Content-Type':content_type, 'Content-Length':len(data)}
        elif data:
            data = json.dumps(data)

        request = urllib2.Request(url, data, headers=headers)
        conn = urllib2.urlopen(request)

        result = conn.read()
        conn.close()

        return result

    def echo(self):
        try:
            version = urllib2.urlopen(self.make_url('/echo')).read()
            self.version = version
        except urllib2.URLError as e:
            return False
        return True

    def close(self):
        self.drop()

    def stat(self):
        return json.loads(self.request('stat', data={'Hash': self.hash}))

    def list(self):
        return json.loads(self.request('list', data={'Hash': self.hash}))

    def get(self):
        return json.loads(self.request('get', data={'Hash': self.hash}))
        
    def rem(self):
        self.request('rem', data={'Hash': self.hash})

    def drop(self):
        self.request('drop', data={'Hash': self.hash})

    def upload(self, data):
        r = json.loads(self.request('upload', data=data, is_file=True))
        self.hash = r[0]
        return True

    def is_preloading(self):
        try:
            st = self.stat()
            return any(x for x in ['preload', 'info'] if x in st['TorrentStatusString'])
        except KeyError:
            pass
        return False

    def preload(self, url):
        try:
            conn = urllib2.urlopen(url, timeout=1.0).read(128)
        except:
            pass

    def start(self, torrent, index=0, preload_size=20):
        self._index = index
        self._preload_size = preload_size
        self.upload(torrent)

        preload_url = self._get_url('Preload')
        preload_url = preload_url.replace('&preload=true', '&preload={}'.format(self._preload_size)) # 1.77
        preload_url = preload_url.replace('/preload/', '/preload/{}/'.format(self._preload_size)) # 1.76

        self.preload(preload_url)

    def status(self):
        st = self.stat()
        try:
            seeders = st['ConnectedSeeders']
            preloaded = st['PreloadedBytes'] / 1024 / 1024
            preload = st['PreloadSize'] / 1024 / 1024
            speed = st['DownloadSpeed'] / 1024 / 1024
        except KeyError:
            return 0, 0, 0, 0
        return seeders, preloaded, preload, speed

    def _get_url(self, mode='Link'):
        try:
            files = self.get()['Files']
        except Exception:
            return None

        for i, f in enumerate(files):
            if i == self._index:
                return self.make_url(f[mode])

