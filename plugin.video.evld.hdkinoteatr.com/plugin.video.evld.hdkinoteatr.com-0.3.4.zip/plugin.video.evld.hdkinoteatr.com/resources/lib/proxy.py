import os
import threading
import urllib
import time
import base64
import urlparse
import SocketServer
import SimpleHTTPServer

import xbmc

PORT = 51344

PROXY_ADDR = 'http://localhost:{}'.format(PORT)

class ThreadedTCPServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    pass

class MyProxy(SimpleHTTPServer.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass


    def do_GET(self):
        if self.path[:3] == '/?=':
            url = self.path[3:]
            if '.m3u8' in url:
                self.replace_urls(url)
            elif '.ts' in url:
                newurl = self.encode_url(url)
                self.send_response(301)
                self.send_header('Location', newurl)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()


    def replace_urls(self, url):
        req = urllib.urlopen(url)
        data = req.read()

        if '#EXT-X-PLAYLIST-TYPE:VOD' in data:
            path = os.path.dirname(url)
            result = data.replace('?x-nb', '').replace('seg-', '{0}/?={1}/seg-'.format(PROXY_ADDR, path))
        else:
            result = data.replace('https://', '{}/?=https://'.format(PROXY_ADDR))

        self.send_response(200)

        for k,v in dict(req.info()).items():
            if k.lower() == 'content-length':
                self.send_header(k, len(result))
            else:
                self.send_header(k, v)

        self.end_headers()
        self.wfile.write(result)


    def encode_url(self, url):
        def encode(txt):
            result = ''
            for e in txt:
                t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".find(e)
                result = result + (e if t < 0 else "DlChEXitLONYRkFjAsnBbymWzSHMqKPgQZpvwerofJTVdIuUcxaG"[t])
            return result

        g = '/x-en-x/'
        n = round(int(time.time() * 1000) / 1000.0 / 60 / 60)

        url_parts = (urlparse.urlsplit(url))

        base = base64.b64encode("%d/%s%s" % (n, url_parts.path, url_parts.query))
        encoded_base = encode(base)

        return '%s://%s%s%s' % (url_parts.scheme, url_parts.netloc, g, encoded_base)


def start():
    httpd = ThreadedTCPServer(('', PORT), MyProxy)
    threading.Thread(target=httpd.serve_forever).start()

    while not xbmc.abortRequested:
        xbmc.sleep(4000)
                
    try:
        httpd.shutdown()
    except:
        pass
