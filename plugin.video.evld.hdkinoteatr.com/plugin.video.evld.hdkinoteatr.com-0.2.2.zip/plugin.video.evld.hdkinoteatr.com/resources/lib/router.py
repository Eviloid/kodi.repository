# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin
import sys, os, urllib

from scraper import HDKinoTeatrScraper, ScraperException
import utils

class Router():
    def __init__(self):
        self._plugin = None
        self._params = {}
        self.routes = self._get_routes()

    def _get_routes(self):
        routes = {
            'categories': self._show_categories,
            'releases': self._show_releases,
            'seasons': self._show_releases,
            'episodes': self._show_releases,
            'search': self._search,
            'play': self._play,
            'home': self._home,
            'info': self._info,
            'cleancache': self._cleancache,
        }
        return routes

    def _add_item(self, title, params={}, arts={}, plot='', isFolder=False, isPlayable=False, url=None, menu=None):
        if url is None:
            url = '%s?%s' % (self._plugin.url, urllib.urlencode(params))

        item = xbmcgui.ListItem(title, iconImage = arts.get('icon'), thumbnailImage = arts.get('thumb'))
        item.setInfo(type='video', infoLabels={'title':title, 'plot':plot})

        if isPlayable:
            item.setProperty('isPlayable', 'true')
            item.setProperty('mediatype', 'video')
    
        item.setArt({'fanart': arts.get('fanart', self._plugin.fanart)})

        if arts.get('banner'):
            item.setArt({'banner': arts['banner']})
        if arts.get('poster'):
            item.setArt({'poster': arts['poster']})
        if arts.get('thumb'):
            item.setArt({'thumb' : arts['thumb']})

        if menu:
            item.addContextMenuItems(menu)

        xbmcplugin.addDirectoryItem(self._plugin.handle, url=url, listitem=item, isFolder=isFolder)

    def _main_menu(self):
        page = self._params.get('page')
        category = self._params.get('category', '')
        query = self._params.get('query')
        show_rating = self._plugin.get_setting('ShowRating') == 'true'

        if category:
            xbmcplugin.setPluginCategory(self._plugin.handle, category=category.strip('/').replace('/', ' ').capitalize())
        elif query:
            xbmcplugin.setPluginCategory(self._plugin.handle, category='Search')

        scraper = HDKinoTeatrScraper(page=page, category=category, query=query, show_rating=show_rating)

        if not page > 1 and not category and not query:
            self._add_item('[B]Категории[/B]', {'mode':'categories'}, isFolder=True)
            self._add_item('[B]Поиск[/B]', {'mode':'search'}, arts={'icon':'DefaultAddonsSearch.png'}, isFolder=True)

        items = scraper.get_all()

        for item in items:
            title = item.get('title', '')
            image = item.get('img')
            plot  = item.get('plot', '')
            url   = item.get('url', '')
            menu = [('Info', 'RunPlugin("%s?mode=info&u=%s")' % (self._plugin.url, urllib.quote_plus(url)))]

            self._add_item(title, {'mode':'releases', 'u':url}, arts={'banner':image, 'poster':image}, plot=plot, isFolder=True, menu=menu)

        if scraper.total_page > 0:
            if scraper.total_page >= scraper.page + 1:
                self._params['page'] = scraper.page + 1
                self._add_item('Далее > {0} из {1}'.format(scraper.page + 1, scraper.total_page), params=self._params, isFolder=True)

            if scraper.page > 2:
                self._add_item('<< В начало', params={'mode':'home'}, isFolder=True)

        xbmcplugin.endOfDirectory(self._plugin.handle, True)

    def _show_categories(self):
        scraper = HDKinoTeatrScraper()

        items = scraper.get_categories()

        for item in items:
            title  = item.get('title', '')
            url    = item.get('url')

            self._add_item(title, {'category':url}, isFolder=True)

        xbmcplugin.endOfDirectory(self._plugin.handle, True)

    def _show_releases(self):
        scraper = HDKinoTeatrScraper()

        url = self._params.get('u')
        release = self._params.get('r')
        season  = self._params.get('s')
        episode = self._params.get('e')

        items = scraper.get_releases(url, release, season, episode)

        plot = scraper.info['plot']

        for item in items:
            title  = item.get('title', '')
            image  = item.get('img')
            vid    = item.get('id')

            params = {'u':url}

            if item.get('type') == 'translation':
                mode = 'seasons'
                params['r'] = vid

            if item.get('type') == 'season':
                mode = 'episodes'
                params['r'] = release
                params['s'] = vid

            if item.get('type') == 'play':
                mode = 'play'
                params['r'] = release
                params['s'] = season
                params['e'] = vid

            params['mode'] = mode

            params = {k: v for k, v in params.items() if v is not None}

            self._add_item(title, params, arts={'icon':self._plugin.icon}, plot=plot, isFolder=mode!='play', isPlayable=mode=='play')

        xbmcplugin.endOfDirectory(self._plugin.handle, True)

    def _home(self):
        xbmc.executebuiltin('Container.Update({}, replace)'.format(self._plugin.url))
        xbmcplugin.endOfDirectory(self._plugin.handle, False)

    def _info(self):
        scraper = HDKinoTeatrScraper()
        scraper.get_releases(self._params['u'])
        dialog = xbmcgui.Dialog()
        item = xbmcgui.ListItem()
        item.setArt({'poster': scraper.info.get('poster')})
        info = {'mediatype': 'movie'}
        info.update(scraper.info)
        item.setInfo(type='video', infoLabels=info)
        dialog.info(item)
    
    def _search(self):
        keywords = self._params.get('query')

        if not keywords:
            kbd = xbmc.Keyboard('', 'Поиск:')
            kbd.doModal()
            if kbd.isConfirmed():
                keywords = kbd.getText()

        if keywords:
            self._params['query'] = keywords
            self._main_menu()

    def _play(self):
        scraper = HDKinoTeatrScraper()

        url = self._params.get('u')
        release = self._params.get('r')
        season  = self._params.get('s')
        episode = self._params.get('e')

        purl = scraper.get_video(url, release, season, episode)

        item = xbmcgui.ListItem(path=purl)
        info = {'mediatype': 'movie'}
        info.update(scraper.info)
        if episode:
            info.update({'mediatype': 'episode', 'tvshowtitle': scraper.info['title'], 'title': None})

        item.setInfo(type='video', infoLabels=info)

        xbmcplugin.setResolvedUrl(self._plugin.handle, True, item)

    def _cleancache(self):
        utils.clean_cache()

    def route(self, plugin):
        self._plugin = plugin

        for key, value in plugin.params.items():
            self._params[key] = urllib.unquote_plus(value)

        route = self.routes.get(plugin.params.get('mode'))
        if route:
            return route()

        return self._main_menu()
