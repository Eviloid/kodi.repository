# GoodGame.ru video addon
Дополнение Kodi для просмотра стримов GoodGame.ru
