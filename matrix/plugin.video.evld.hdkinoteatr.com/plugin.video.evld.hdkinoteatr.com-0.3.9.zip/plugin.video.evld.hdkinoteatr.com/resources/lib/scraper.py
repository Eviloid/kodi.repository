# -*- coding: utf-8 -*-

import re
import json

from urllib.error import HTTPError

import CommonFunctions as common
import utils

from proxy import PROXY_ADDR


BASE_URL = utils.BASE_URL

class ScraperException(Exception):
    pass


class CollapsPlayerParser():
    def __init__(self, url):
        self._html = self.fetch(url + '?host=www.hdkinoteatr.com')

    @staticmethod
    def fetch(url, params={}, post={}, headers={}):
        return utils.get_html(url, params, post, headers)

    def get_items(self, translation=None, season=None, episode=None):
        items = []

        m = re.search(r'(source:.*}),.*quality', self._html, re.S)
        if m:
            data = re.sub("((?=\D)\w+): ", r'"\1": ', m.group(1))
            data = json.loads('{%s}' % data)

            if data.get('source'):
                uri = data['source'].get('hls', '')
                items.append({'title':'Смотреть', 'url':uri, 'type':'play'})

        else:
            m = re.search(r'(seasons:.*}),.*quality', self._html, re.S)
            if m:
                data = '{%s' % m.group(1)
                data = re.sub(r'([^\w\"\.])(\w+)\s*:', r'\1"\2":', data)
                data = json.loads(data)

                for s in data.get('seasons'):
                    if season:
                        if s['season'] == int(season):
                            for e in s.get('episodes'):
                                if episode:
                                    if e['episode'] == episode:
                                        uri = e.get('hls', '')
                                        items.append({'title':e['title'], 'url':uri, 'id':episode, 'type':'play'})
                                        break
                                else:
                                    items.append({'title':e['title'], 'id':e['episode'], 'type':'play'})
                    else:
                        title = 'Сезон %d' % s['season']
                        items.append({'title':title, 'id':s['season'], 'type':'season'})


        return items

    def get_video(self, translation=None, season=None, episode=None):
        items = self.get_items(translation, season, episode)
        purl = ''

        if items:
            return '{0}/?={1}'.format(PROXY_ADDR, items[0].get('url', ''))
        return purl


class CDNPlayerParser():
    def __init__(self, url):
        self._html = self.fetch(url)

    @staticmethod
    def fetch(url, params={}, post={}, headers={}):
        return utils.get_html(url, params, post, headers)

    @staticmethod
    def make_title(title):
        for _ in range(2):
            title = title.replace('<br><i>', ' [COLOR=gray]')
            title = title.replace('</i>', '[/COLOR]')
            title = common.replaceHTMLCodes(title)
        return title

    @staticmethod
    def parse_video(files):
        urls = re.findall(r'\[(.*?)p\]((\/\/.+?)(,|$))*', files)
        for url in reversed(urls):
            uri = url[1].split('or')[0]
            uri = uri.split('?dn=', 1)[0]
            uri = re.sub(r'^//', 'https://', uri)
            if utils.check_url(uri):
                break
        return uri

    def get_items(self, translation=None, season=None, episode=None):
        items = []

        m = re.search('id="files" value=\'(.*?)\'', self._html)
        if m:
            data = json.loads(m.group(1).replace('&quot;', '"'))
        else:
            data = None

        translations = common.parseDOM(self._html, 'div', attrs={'class':'translations'})

        if not translations or translation or season or episode:
            if data:
                data = data.get(translation, list(data.values())[0])

                if isinstance(data, str):
                    uri = self.parse_video(data)
                    if uri:
                        items.append({'title':'Смотреть', 'url':uri, 'type':'play'})

                else:
                    seasons = data

                    for s in seasons:
                        title = self.make_title(s['comment'])
                        episodes = s.get('folder')
                        if season:
                            if not s['id'] == int(season):
                                continue
                            if episodes:
                                for e in episodes:
                                    if episode:
                                        if not e['id'] == episode:
                                            continue
                                    title = self.make_title(e['comment'])
                                    uri = self.parse_video(e['file'])
                                    if uri:
                                        items.append({'title':title, 'url':uri, 'id':e['id'], 'type':'play'})

                        elif episode:
                            if not s['id'] == episode:
                                continue
                            if s.get('file'):
                                uri = self.parse_video(s['file'])
                                if uri:
                                    items.append({'title':title, 'url':uri, 'id':s['id'], 'type':'play'})

                        else:
                            if s.get('file'):
                                uri = self.parse_video(s['file'])
                                if uri:
                                    items.append({'title':title, 'url':uri, 'id':s['id'], 'type':'play'})
                            else:
                                items.append({'title':title, 'id':s['id'], 'type':'season'})

        else:
            if translations:
                studios = common.parseDOM(translations, 'option')
                ids = common.parseDOM(translations, 'option', ret='value')
                for i, studio in enumerate(studios):
                    if ids[i] != '0':
                        title = common.stripTags(studio).replace('[email&#160;protected]', 'MUZOBOZ@')
                        title = self.make_title(title)
                        items.append({'title':title, 'id':ids[i], 'type':'translation'})

        return items

    def get_video(self, translation=None, season=None, episode=None):
        items = self.get_items(translation, season, episode)
        purl = ''

        if items:
            return items[0].get('url', '')
        return purl


class HDKinoTeatrScraper():
    def __init__(self, page=None, query=None, category='', show_rating=False):
        self.page = int(page or 1)
        self._query = query
        self._category = category
        self._show_rating = show_rating

        self._total_page = 0
        self._html = ''

        self._info = {'title':'', 'originaltitle':'', 'plot':'', 'year':'', 'country':''}
        self._poster = ''

    @property
    def total_page(self):
        return self._total_page

    @property
    def info(self):
        return self._info

    @property
    def poster(self):
        return self._poster

    @staticmethod
    def fetch(url, params={}, post={}, headers={}):
        return utils.get_html(url, params, post, headers)

    def make_url(self):
        return '{0}{1}'.format(BASE_URL, self._category.rstrip('/'))

    def _get_parser(self):
        parser = None
        player = common.parseDOM(self._html, 'div', attrs={'id':'videoCDN-player'})
        if player:
            iframe = common.parseDOM(player, 'iframe', ret='src')[0]
            try:
                parser = CDNPlayerParser(re.sub(r'^//', 'https://', iframe))
            except:
                pass
        if parser is None:
            player = common.parseDOM(self._html, 'div', attrs={'id':'player_collaps'})
            if player:
                iframe = common.parseDOM(player, 'iframe', ret='src')[0]
                parser = CollapsPlayerParser(iframe)
        return parser

    def _check_pagination(self):
        self._total_page = 0

        pagination = common.parseDOM(self._html, 'div', attrs={'class':'navigation'})
        if pagination:
            pages = common.parseDOM(pagination[0], 'a')

            for i in pages[::-1]:
                if i.isdigit():
                    break
            if i.isdigit():
                self._total_page = int(i)

    def _parse_info(self):
        content = common.parseDOM(self._html, 'script', attrs={'type':'application\/ld\+json'})
        if content:
            data = json.loads(content[0])
            self._poster = data['image']
            self._info['title'] = data['name']
            if isinstance(data['alternateName'], list):
                self._info['originaltitle'] = data['alternateName'][0]
            else:
                self._info['originaltitle'] = data['alternateName'] or self._info['title']
            self._info['plot'] = data['description']
            self._info['year'] = data.get('dateCreated', '').split('-')[0]
            if isinstance(data['countryOfOrigin'], list):
                self._info['country'] = ', '.join(country.get('name', '') for country in data['countryOfOrigin'])
            else:
                self._info['country'] = data['countryOfOrigin']['name'] if data.get('countryOfOrigin') else ''


    def _parse_categories(self):
        items = []

        content = common.parseDOM(self._html, 'ul', attrs={'class':'cats'})
        if content:
            categories = common.parseDOM(content[0], 'li')

            for category in categories:
                title = common.parseDOM(category, 'a')[0]
                url = common.parseDOM(category, 'a', ret='href')[0]

                items.append({'title':title, 'url':url})

        return items
            

    def _parse_shows(self):
        items = []

        content = common.parseDOM(self._html, 'div', attrs={'id':'dle-content'})
        releases = common.parseDOM(content, 'div', attrs={'class':'base shortstory'})

        for release in releases:
            img = ''

            container = common.parseDOM(release, 'div', attrs={'class':'img'})
            if container:
                image = common.parseDOM(container, 'a', ret='href')
                if not image:
                    image = common.parseDOM(container, 'img', ret='src')
                if image:
                    img = BASE_URL + image[0]

            container = common.parseDOM(release, 'div', attrs={'class':'story'})
            if container:
                title = common.parseDOM(container, 'a')[0]
                title = title.replace('<span class="hilight">', '[COLOR=blue]').replace('</span>', '[/COLOR]')
                url = common.parseDOM(container, 'a', ret='href')[0]

            genre = ''

            container = common.parseDOM(release, 'p', attrs={'class':'.*?argcat'})
            if container:
                genre = '[COLOR=blue]{}[/COLOR]\n\n'.format(', '.join(common.parseDOM(container, 'a')))

            plot = genre

            desc = common.parseDOM(release, 'div', attrs={'class':'descr'})
            if desc:
                plot = plot + desc[0].replace('<span class="hilight">', '[COLOR=blue]').replace('</span>', '[/COLOR]')
                plot = common.stripTags(common.replaceHTMLCodes(plot))

            if self._show_rating:
                rating = common.parseDOM(release, 'span', attrs={'class':'imdb_rating'})
                if rating:
                    plot = '[COLOR=yellow][B]IMDb: {0}[/B][/COLOR]\n{1}'.format(rating[0], plot)

            title = re.sub(r'(\()(\d\d\d\d)', r'[COLOR=gray]\2', title)
            title = re.sub(r'(\d\d\d\d)(\))', r'\1[/COLOR]', title)


            items.append({'title':title, 'url':url, 'img':img, 'plot':plot})
        return items


    def _parse_releases(self, release=None, season=None, episode=None):
        self._parse_info()

        parser = self._get_parser()
        items = parser.get_items(release, season, episode) if parser else []

        return items

    def get_video(self, url, release=None, season=None, episode=None):
        self._html = self.fetch(url)
        self._parse_info()

        parser = self._get_parser()
        purl = parser.get_video(release, season, episode) if parser else ''

        return purl

    def get_all(self):
        query = self._query

        if query:
            post = {'do':'search', 'subaction':'search', 'search_start':self.page, 'story':query, 'full_search':0, 'result_from':1}
            self._html = self.fetch('{}/index.php'.format(BASE_URL), params={'do':'search'}, post=post)
        else:
            self._html = self.fetch('{0}/page/{1}/'.format(self.make_url(), self.page))

        self._check_pagination()
        return self._parse_shows()

    def get_categories(self):
        self._html = self.fetch(BASE_URL)
        return self._parse_categories()

    def get_releases(self, url, release=None, season=None, episode=None):
        self._html = self.fetch(url)
        return self._parse_releases(release, season, episode)

