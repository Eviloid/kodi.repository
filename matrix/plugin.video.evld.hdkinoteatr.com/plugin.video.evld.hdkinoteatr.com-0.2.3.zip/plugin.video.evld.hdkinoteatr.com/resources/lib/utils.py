# -*- coding: utf-8 -*-

import os, urllib

import CommonFunctions as common

__all__ = ['get_html', 'get_params', 'clean_cache', 'BASE_URL']

BASE_URL = 'https://www.hdkinoteatr.com'

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'

def get_html(url, params={}, post={}, headers={}):
    headers['User-Agent'] = USER_AGENT

    if params:
        url = '{0}?{1}'.format(url, urllib.parse.urlencode(params))

    if post:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        request = urllib.request.Request(url, urllib.parse.urlencode(post).encode('utf-8'), headers=headers)
    else:
        headers['Accept-Encoding'] = 'gzip, identity'
        request = urllib.request.Request(url, headers=headers)

    conn = urllib.request.urlopen(request)

    data = conn.read()

    if conn.headers.get('Content-Encoding', '') == 'gzip':
        import zlib
        data = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(data)

    conn.close()
    return data


def get_params(argv):
    param = {}
    paramstring = argv
    if len(paramstring) >= 2:
        params = argv
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


def clean_cache():
    from tccleaner import TextureCacheCleaner as tcc
    tcc().remove_like('%hdkinoteatr.com/uploads%', True)
