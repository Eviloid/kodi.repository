import os
import threading
import urllib.request
import urllib.parse
import time
import base64
import socketserver as SocketServer
import http.server as SimpleHTTPServer

import xbmc

PORT = 51344

PROXY_ADDR = 'http://localhost:{}'.format(PORT)

class ThreadedTCPServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    pass

class MyProxy(SimpleHTTPServer.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass


    def do_GET(self):
        if self.path[:3] == '/?=':
            url = self.path[3:]
            if '.m3u8' in url:
                self.replace_urls(url)
            elif '.ts' in url:
                newurl = self.encode_url(url)
                self.send_response(301)
                self.send_header('Location', newurl)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()


    def replace_urls(self, url):
        req = urllib.request.urlopen(url)
        data = req.read().decode('utf-8')

        if '#EXT-X-PLAYLIST-TYPE:VOD' in data:
            path = os.path.dirname(url)
            result = data.replace('?x-nb', '').replace('seg-', '{0}/?={1}/seg-'.format(PROXY_ADDR, path))
        else:
            result = data.replace('https://', '{}/?=https://'.format(PROXY_ADDR))

        self.send_response(200)

        result = result.encode('utf-8')

        for k,v in dict(req.getheaders()).items():
            if k.lower() == 'content-length':
                self.send_header(k, len(result))
            else:
                self.send_header(k, v)

        self.end_headers()
        self.wfile.write(result)


    def encode_url(self, url):
        def encode(txt):
            result = ''
            for e in txt:
                t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".find(e)
                result = result + (e if t < 0 else "DlChEXitLONYRkFjAsnBbymWzSHMqKPgQZpvwerofJTVdIuUcxaG"[t])
            return result

        g = '/x-en-x/'
        n = round(time.time() / 60 / 60)

        url_parts = (urllib.parse.urlsplit(url))

        base = base64.b64encode("{0}/{1}{2}".format(n, url_parts.path, url_parts.query).encode('utf-8'))
        encoded_base = encode(base.decode('utf-8'))

        return '{0}://{1}{2}{3}'.format(url_parts.scheme, url_parts.netloc, g, encoded_base)


def start():
    httpd = ThreadedTCPServer(('', PORT), MyProxy)
    threading.Thread(target=httpd.serve_forever).start()

    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        xbmc.sleep(4000)
                
    try:
        httpd.shutdown()
    except:
        pass
