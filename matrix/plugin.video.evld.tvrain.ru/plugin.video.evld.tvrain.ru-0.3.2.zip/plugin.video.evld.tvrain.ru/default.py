# -*- coding: utf-8 -*-

import os
import sys
import json
import re

import urllib.parse
import urllib.request

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import CommonFunctions

import datetime

#fix for datatetime.strptime returns None
class proxydt(datetime.datetime):
    @staticmethod
    def strptime(date_string, format):
        import time
        return datetime.datetime(*(time.strptime(date_string, format)[0:6]))

datetime.datetime = proxydt


try:handle = int(sys.argv[1])
except:pass

addon = xbmcaddon.Addon(id='plugin.video.evld.tvrain.ru')

BASE_URL = 'https://tvrain.tv'
API_URL = 'https://api.tvrain.tv/api_v2'


Pdir = addon.getAddonInfo('path')
main_icon = xbmcvfs.translatePath(os.path.join(Pdir, 'icon.png'))
main_fanart = xbmcvfs.translatePath(os.path.join(Pdir, 'fanart.jpg'))
default_preview = f'{BASE_URL}/library/512x280/b4085e/media/upload/images/teleshow/Archive.png'

xbmcplugin.setContent(handle, 'videos')

common = CommonFunctions
common.plugin = addon.getAddonInfo('name')


live_quality = {
    'Site': 'https://1040819719.rsc.cdn77.org/transcode/ngrp:ses_all/playlist.m3u8',
    'Авто': 'Автоматическое определение качества',
    'Высокое': 'Высокое качество',
    'Среднее': 'Среднее качество',
    'Низкое': 'Низкое качествo',
    }


def_headers = {'Accept'                         : 'application/tvrain.api.2.24+json',
               'Accept-Language'                : 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
               'User-Agent'                     : 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
               'Accept-Encoding'                : 'gzip, deflate',
               'X-User-Agent'                   : 'TV Client (Browser); API_CONSUMER_KEY=a908545f-1cea-7741-a0a0-9fca0010',
               'X-Result-Define-Thumb-Width'    : '512',
               'X-Result-Define-Thumb-height'   : '280',
               'X-Result-Define-Video-Only-Flag': '1',
               'Referer'                        : 'http://smarttv.tvrain.tv/',
               'Origin'                         : 'http://smarttv.tvrain.tv',
               'Connection'                     : 'keep-alive',
            }


def get_html(url, params=None, post=None, headers={}):

    if url[:4] != 'http':
        url = API_URL + url

    if params:
        url = '{0}?{1}'.format(url, urllib.parse.urlencode(params))

    if post:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        request = urllib.request.Request(url, urllib.parse.urlencode(post).encode('utf-8'))
    else:
        request = urllib.request.Request(url)

    for key, val in def_headers.items():
        request.add_header(key, val)

    for key, val in headers.items():
        request.add_header(key, val)

    html = '{}'

    try:
        conn = urllib.request.urlopen(request)
        html = conn.read()

        if conn.headers.get('Content-Encoding', '') == 'gzip':
            import zlib
            html = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(html)

        if conn.headers.get_content_charset():
            html = html.decode(conn.headers.get_content_charset())

        if isinstance(html, bytes):
            html = html.decode('utf-8')

        conn.close()

    except Exception as e:
        xbmcgui.Dialog().notification(common.plugin, str(e), main_icon, 2000, True)

    return html


def fix_img(url):
    return url.replace('//api.', '//')


def add_item(title, params={}, icon=None, banner=None, fanart=None, poster=None, thumb=None, plot=None, isFolder=True, isPlayable=False, url=None):
    item = xbmcgui.ListItem(title)

    il = {'title': title, 'plot': plot}

    if params.get('mode') == 'live':
        il['watched'] = 'false'

    item.setInfo(type='video', infoLabels=il)

    if isPlayable:
        item.setProperty('mediatype', 'video')
        item.setProperty('isPlayable', 'true')

    fanart = fanart or main_fanart

    if icon:
        item.setArt({'icon': icon})
    if thumb:
        item.setArt({'thumb': thumb})
    if banner:
        item.setArt({'banner': banner})
    if fanart:
        item.setArt({'fanart': fanart})
    if poster:
        item.setArt({'poster': poster})
    if thumb:
        item.setArt({'thumb': thumb})

    if url is None:
        url = '{0}?{1}'.format(sys.argv[0], urllib.parse.urlencode(params))
        item.setContentLookup(False)

    xbmcplugin.addDirectoryItem(handle, url=url, listitem=item, isFolder=isFolder)


def main_menu():
    add_item('[B]Эфир[/B]', {'mode':'live'}, icon=main_icon, isPlayable=True, isFolder=False)
    add_item('Популярное', {'mode':'popular'})
    add_item('Наш Выбор', {'mode':'ourchoice'})
    add_item('Программы', {'mode':'programs'})
    add_item('Всё видео', {'mode':'all'})
    add_item('Поиск', {'mode':'search'}, icon='DefaultAddonsSearch.png')

    xbmcplugin.endOfDirectory(handle)


def live():
    quality = live_quality.get(addon.getSetting('LiveQuality'))

    if any(x for x in ['.mpd', '.m3u8'] if x in quality):
        purl = quality
    else:
        html = get_html('/live/')
        data = json.loads(html)

        streams = data.get('HLS_SMARTTV')

        if streams:
            for i in streams:
                if i['label'] == quality:
                    purl = i['url']
        else:
            return

    item = xbmcgui.ListItem(path=purl)
    item.setInfo(type='video', infoLabels={'title':'ДО///ДЬ Live', 'plot':'Прямой эфир'})

    if addon.getSetting('UseStreamAdaptive') == 'true':
        item.setProperty('inputstream', 'inputstream.adaptive')

    if '.mpd' in purl:
        item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        item.setProperty('inputstream.adaptive.license_key', 'https://cwip-shaka-proxy.appspot.com/no_auth||R{SSM}|')
    
        item.setMimeType('application/dash+xml')
        item.setContentLookup(False)
    else:
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(handle, True, item)


def play(params):
    url = None

    html = get_html('/articles/{}/'.format(params['id']))
    data = json.loads(html)

    if data[params['id']].get('only_vip', 0) == 1:
        # полное видео пробуем получить с сайта, API даёт ознакомительный фрагмент
        html = get_html(data[params['id']]['fullurl'])

        s = re.search(r'paramsPlayer.+"source":"(.+?)"', html)
        if s:
            url = s.group(1).replace(r'\/', '/')
    else:
        html = get_html('/articles/{}/auto/'.format(params['id']))
        data = json.loads(html)
        if len(data) > 0:
            url = data[0]['auto']['data']

    if url:
        item = xbmcgui.ListItem(path=url)
        if addon.getSetting('UseStreamAdaptive') == 'true':
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        xbmcplugin.setResolvedUrl(handle, True, item)


def show_articles(data):
    for i in data:
        name = i['name']
        plot = i.get('preview_text', name)
        title = common.replaceHTMLCodes(name)
        label = '[B][COLOR=FFCF3476]{}[/COLOR][/B]\n'.format(i['program']['name'])

        if i.get('date_active_start'):
            date = i['date_active_start']
        else:
            date = i['date']

        if ',' in date:
            date_template = '%a, %d %b %y %H:%M:%S %z'  # Fri, 28 Feb 20 11:53:44 +0300
        else:
            date_template = '%Y-%m-%dT%H:%M:%S%z'       # 2022-02-20 22:17:35+0300

        dt = datetime.datetime.strptime(date, date_template)
        plot = '{0}[B]{1}[/B]\n{2}'.format(label, dt.strftime('%d/%m/%Y'), common.replaceHTMLCodes(plot).strip())

        preview = i.get('preview_img', i.get('img')) or default_preview

        add_item(title, {'mode':'play', 'id':i['id']}, thumb=fix_img(preview), plot=plot, isPlayable=True, isFolder=False)


def popular(params):
    period = params.get('period')

    if period:
        html = get_html('/widgets/popular/', headers={'X-Result-Define-Period':f'{period}'})
        data = json.loads(html)

        show_articles(data['elements'])
    else:
        add_item('За неделю',     {'mode':'popular','period':'1w'})
        add_item('За месяц',      {'mode':'popular','period':'1m'})
        add_item('За три месяца', {'mode':'popular','period':'3m'})
        add_item('За полгода',    {'mode':'popular','period':'6m'})
        add_item('За год',        {'mode':'popular','period':'12m'})
        add_item('За всё время',  {'mode':'popular','period':'forever'})

    xbmcplugin.endOfDirectory(handle)


def ourchoice(params):
    html = get_html('/widgets/ourchoice/')
    data = json.loads(html)

    show_articles(data)
    
    xbmcplugin.endOfDirectory(handle)


def programs(params):
    cid = params.get('cid')

    if cid is None:
        html = get_html('/programs/categories/')
        data = json.loads(html)

        add_item('Популярные программы', {'mode':'programs', 'cid':'cool'})
        for i in data['elements']:
            add_item(data['elements'][i], {'mode':'programs', 'cid':i})
    else:
        html = get_html('/programs/', headers={'X-Result-Define-Pagination':'1/250'})
        data = json.loads(html)

        for i in data['elements']:
            if cid == 'cool':
                if not i['is_cool'] == 1:
                    continue
            else:
                if not int(cid) in i['categories']:
                    continue
            add_item(i['name'], {'mode':'program', 'id':i['id']}, thumb=fix_img(i['preview_img']), plot=i.get('detail_text', i['name']))

    xbmcplugin.endOfDirectory(handle)


def program(params):
    page = params.get('page', '1')

    html = get_html('/programs/{}/articles/'.format(params['id']), headers={'X-Result-Define-Pagination':f'{page}/20'})
    data = json.loads(html)

    current_page = data['current_page']
    total_pages  = data['total_pages']

    show_articles(data['elements'])

    if current_page < total_pages:
        title = 'Далее > {0} из {1}'.format(current_page + 1, total_pages)
        params.update({'page':current_page + 1})
        add_item(title, params)
    if current_page > 2:
        add_item('<< В начало', {'mode':'home'}, icon='DefaultFolderBack.png')

    xbmcplugin.endOfDirectory(handle)


def all_video(params):
    page = params.get('page', '2')
    query = params.get('q', '')

    html = get_html('/search/', params={'query':query, 'category':'Video', 'only_video':'true'}, headers={'X-Result-Define-Pagination':f'{page}/20'})
    data = json.loads(html)

    current_page = data['current_page']
    total_pages  = data['total_pages']

    show_articles(data['elements'])

    if current_page < total_pages:
        title = 'Далее > {0} из {1}'.format(current_page, total_pages)
        params.update({'page':current_page + 1})
        add_item(title, params)
    if current_page > 3:
        add_item('<< В начало', {'mode':'home'}, icon='DefaultFolderBack.png')

    xbmcplugin.endOfDirectory(handle)


def search(params):
    keywords = urllib.parse.unquote_plus(params.get('q', ''))

    if not keywords:
        kbd = xbmc.Keyboard('', 'Поиск:')
        kbd.doModal()
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        if kbd.isConfirmed():
            keywords = kbd.getText()
            if keywords:
                xbmc.executebuiltin('Container.Update({0}?mode=search&q={1}, replace)'.format(sys.argv[0], urllib.parse.quote_plus(keywords)))
                return
        xbmc.executebuiltin('Container.Update({}, replace)'.format(sys.argv[0]))

    else:
        all_video(params)
        xbmcplugin.endOfDirectory(handle)


if addon.getSetting('IsAuthorized') == 'true':
    def_headers['Authorization'] = addon.getSetting('Authorization')


params = common.getParameters(sys.argv[2])

mode = params['mode'] = params.get('mode', '')

if mode == '':
    main_menu()

elif mode == 'live':
    live()

elif mode == 'play':
    play(params)

elif mode == 'ourchoice':
    ourchoice(params)

elif mode == 'programs':
    programs(params)

elif mode == 'program':
    program(params)

elif mode == 'popular':
    popular(params)

elif mode == 'all':
    all_video(params)

elif mode == 'search':
    search(params)

elif mode == 'login':
    user = addon.getSetting('User')
    password = addon.getSetting('Password')

    html = get_html('/user/auth/', post={'email':user, 'passw':password})
    data = json.loads(html)

    if 'device_token' in data:
        import base64
        token = base64.b64encode('{0}:{1}'.format(data['user_id'], data['device_token']).encode('utf-8'))
        addon.setSetting('Authorization','Basic {}'.format(token.decode('utf-8')))
        addon.setSetting('IsAuthorized', 'true')

    addon.openSettings()

elif mode == 'logout':
    addon.setSetting('Authorization','')
    addon.setSetting('IsAuthorized', 'false')
    xbmc.executebuiltin('SendClick(10)', True)

elif mode == 'home':
    xbmc.executebuiltin('Container.Update({}, replace)'.format(sys.argv[0]))
    xbmcplugin.endOfDirectory(handle, True, True)

elif mode == 'cleancache':
    from tccleaner import TextureCacheCleaner as tcc
    tcc().remove_like('%tvrain.tv%.jpg', True)
