# -*- coding: utf-8 -*-

import os, sys, re, json

import http.cookiejar as cookielib
import urllib.request as urlrequest
import urllib.parse as urlparse
import urllib.error as urlerror

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

import CommonFunctions as common
from tccleaner import TextureCacheCleaner as tcc

PLUGIN_NAME   = 'Goodgame plugin'

common.plugin = PLUGIN_NAME

LIVE_PREVIEW_TEMPLATE = '%//hls.goodgame.ru/previews/%'  # sqlite LIKE pattern


try:handle = int(sys.argv[1])
except:pass

addon = xbmcaddon.Addon(id='plugin.video.evld.goodgame.ru')

Pdir = addon.getAddonInfo('path')
icon = xbmcvfs.translatePath(os.path.join(Pdir, 'icon.png'))
fanart = xbmcvfs.translatePath(os.path.join(Pdir, 'fanart.jpg'))

fcookies = xbmcvfs.translatePath(os.path.join(Pdir, 'cookies.txt'))
cj = cookielib.MozillaCookieJar(fcookies)


xbmcplugin.setContent(handle, 'videos')

def get_html(url, params={}, post={}, noerror=False):
    headers = {'Accept':'application/json'}

    if post:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        req = urlrequest.Request(url, urlparse.urlencode(post).encode('utf-8'), headers=headers)
    else:
        req = urlrequest.Request('{0}?{1}'.format(url, urlparse.urlencode(params)), headers=headers)

    html = ''

    try:
        conn = urlrequest.urlopen(req)
        data = conn.read()
    except urlerror.HTTPError as err:
        if not noerror:
            return err.code

    if conn.headers.get_content_charset():
        data = data.decode(conn.headers.get_content_charset())

    return data


def do_login():
    if addon.getSetting('User'):
        post = {'username':addon.getSetting('User'), 'password':addon.getSetting('Password')}
        get_html('https://goodgame.ru/api/4/login/password', post=post)

        cj.save(fcookies, True, True)

    xbmc.executebuiltin('Container.Refresh')


def checkauth():
    html = get_html('https://goodgame.ru/api/4/user')

    if isinstance(html, str):
        data = json.loads(html)
        return data.get('error', '')  == ''
    return False


def list_streams(params):

    if params['mode'] == 'favorites':
        html = get_html('https://goodgame.ru/api/4/favorites')
        data = json.loads(html)
        data = {'streams': data}

    else:
        html = get_html('https://goodgame.ru/api/4/stream', {'ggonly':'1','onpage':25,'page':params['page'],'game':params.get('game', '')}) 
        data = json.loads(html)

    if data:
        for s in data['streams']:

            title = s['title']

            if isinstance(s['streamer'], dict):
                streamer = s['streamer']['nickname']
            else:
                streamer = s['streamer']

            title = f'[B]{streamer}[/B] {title}'

            if s.get('gameobj'):
                plot = '[B][COLOR yellow]{0}[/COLOR][/B]\n{1}'.format(s['gameobj']['title'], title)
            else:
                plot = title

            if s['status'] == True:
                preview = 'https:{0}'.format(s['preview'].replace('_240', ''))
            else:
                title = f'[COLOR red]{title}[/COLOR]'
                preview = s['poster']
                if preview[:1] == '/':
                    preview = 'https://goodgame.ru' + preview


            add_item(title, {'mode':'play', 'key':s['channelkey']}, arts={'icon':preview, 'poster':preview, 'fanart':fanart}, plot=plot, isPlayable= s['status'] == True)


        if data.get('queryInfo'):
            if data['queryInfo']['onPage'] > 0:
                page_count = data['queryInfo']['qty'] // data['queryInfo']['onPage'] + 1

                if page_count > data['queryInfo']['page']:
                    next_page = data['queryInfo']['page'] + 1
                    params['page'] = next_page
                    add_nav('Далее > {0:d} из {1:d}'.format(next_page, page_count), params)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_games(params):
    html = get_html('https://goodgame.ru/api/4/stream/games', {'page':params['page']}, noerror=False)
    if not isinstance(html, str):
        if params['page'] > 1:
            params['page'] = params['page'] - 1
            list_games(params)
    else:
        data = json.loads(html)
        for g in data['games']:
            add_item(g['title'], {'mode':'list', 'game':g['url']}, arts={'poster':g['poster'], 'fanart':fanart}, isFolder=True)

        params['page'] = params['page'] + 1
        add_nav('Далее >', params)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def main_menu(params):

    if params.get('game') == None:
        if params['page'] == 1:
            if checkauth():
                add_nav('[B]Избранные стримы[/B]', {'mode':'favorites'})
            add_nav('[B]Игры[/B]', {'mode':'games'})

    list_streams(params)


def play_stream(params):
    quality = {'0':'smil', '1':'source', '2':'720', '3':'480'}

    q = addon.getSetting('Quality')

    html = get_html(f'https://goodgame.ru/api/4/stream/{params["key"]}') 
    data = json.loads(html)

    sources = data['sources']

    if len(sources) == 1:
        purl = sources.itervalues().next()
    else:
        if q == '4':
            lstreams = [s.replace('smil', 'auto') for s in sources]
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Качество потока', lstreams)
            if ret < 0: return
            q = lstreams[ret].replace('auto', 'smil')
        else:
            q = quality.get(q)

        purl = sources.get(q)

    if '.smil' in purl:
        if data['premium']:
            purl = purl.replace('.smil', '_master.m3u8').replace('/hls/', '/manifest/')
        else: 
            purl = purl.replace('.smil', '.m3u8')

    item = xbmcgui.ListItem(path=purl)

    if addon.getSetting('UseStreamAdaptive') == 'true':
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(handle, True, item)


def add_nav(title, params={}):
    url = '{0}?{1}'.format(sys.argv[0], urlparse.urlencode(params))
    item = xbmcgui.ListItem(title)
    xbmcplugin.addDirectoryItem(handle, url=url, listitem=item, isFolder=True)
    

def add_item(title, params={}, arts={}, plot='', isFolder=False, isPlayable=False, url=None):
    if url == None: url = '{0}?{1}'.format(sys.argv[0], urlparse.urlencode(params))

    item = xbmcgui.ListItem(title)
    item.setInfo(type='video', infoLabels={'Title': title, 'Plot': plot, 'watched':'False'})

    if isPlayable:
        item.setProperty('IsPlayable', 'true')

    item.setArt(arts)

    xbmcplugin.addDirectoryItem(handle, url=url, listitem=item, isFolder=isFolder)


try:
    cj.load(fcookies, True, True)
except:
    pass

hr = urlrequest.HTTPCookieProcessor(cj)
opener = urlrequest.build_opener(hr)
urlrequest.install_opener(opener)

params = common.getParameters(sys.argv[2])
params['mode'] = mode = params.get('mode', 'list')
params['page'] = int(params.get('page', 1))

if mode == 'login':
    do_login()

elif mode == 'games':
    list_games(params)

elif mode == 'list':
    tcc().remove_like(LIVE_PREVIEW_TEMPLATE, False)
    main_menu(params)

elif mode == 'favorites':
    tcc().remove_like(LIVE_PREVIEW_TEMPLATE, False)
    params['page'] = 0
    list_streams(params)

elif mode == 'play':
    play_stream(params)

addon = None