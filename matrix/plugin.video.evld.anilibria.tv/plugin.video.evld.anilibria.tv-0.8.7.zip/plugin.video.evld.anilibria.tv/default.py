# -*- coding: utf-8 -*-
# Eviloid, 08.10.2019

import os, sys, re, json

import urllib.parse as urlparse
import urllib.request as urlrequest
import urllib.error as urlerror


import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import CommonFunctions

PLUGIN_NAME   = 'Anilibria.tv'


common = CommonFunctions
common.plugin = PLUGIN_NAME


try:handle = int(sys.argv[1])
except:pass

addon = xbmcaddon.Addon(id='plugin.video.evld.anilibria.tv')

BASE_URL = 'https://{}'.format(addon.getSetting('host'))


Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(Pdir, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(Pdir, 'fanart.jpg'))

xbmcplugin.setContent(handle, 'tvshows')

quality = {0:'1080p', 1:'720p', 2:'480p'}


def get_html(url, params=None, post=None, headers={}):
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'

    if params:
        url = '%s?%s' % (url, urlparse.urlencode(params))

    if post:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        request = urlrequest.Request(url, urlparse.urlencode(post).encode('utf-8'), headers=headers)
    else:
        request = urlrequest.Request(url, headers=headers)

    conn = urlrequest.urlopen(request)
    html = conn.read()
    conn.close()

    if conn.headers.get_content_charset():
        html = html.decode(conn.headers.get_content_charset())

    return html 


def add_youtube(v):
    fan = 'https://i.ytimg.com/vi/%s/maxresdefault.jpg' % v
    img = 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % v

    plot = ''

    API_KEY = 'AIzaSyD2mYqnwgQJb_aNd54Iv4ogaaX6-eM99Pc'
    url = 'https://www.googleapis.com/youtube/v3/videos?part=snippet&id={0}&fields=items/snippet/title,items/snippet/description&key={1}'.format(v, API_KEY)
    try:
        html = get_html(url)
        data = json.loads(html)
        plot = data['items'][0]['snippet']['description']
        title = data['items'][0]['snippet']['title']
    except:
        return False

    add_item(common.replaceHTMLCodes(title), {'mode':'youtube', 'v':v}, thumb=img, fanart=fan, plot=common.replaceHTMLCodes(plot), isPlayable=True)
    return True


def main_menu():
    add_item('[B]Новые[/B]', params={'mode':'new'}, fanart=fanart, isFolder=True)
    add_item('[B]Популярные[/B]', params={'mode':'popular'}, fanart=fanart, isFolder=True)

    html = get_html(BASE_URL)

    container = common.parseDOM(html, 'table', attrs={'class':'youtubeTable'})
    videos = common.parseDOM(container, 'td')
    if videos:
        odd = [v for i, v in enumerate(videos) if i % 2 != 0]
        even = [v for i, v in enumerate(videos) if i % 2 == 0]

        for video in odd + even:
            url = common.parseDOM(video, 'a', ret='href')[0]
            if not add_youtube(re.search(r"\?v=(.*)", url).group(1)):
                img = common.parseDOM(video, 'img', ret='src')[0]
                img = re.sub(r'^/', BASE_URL + '/', img)
                title = common.replaceHTMLCodes(common.parseDOM(video, 'img', ret='alt')[0])
                title = common.replaceHTMLCodes(title)
                add_item(title, {'mode':'youtube', 'v':'%s' % re.search(r"\?v=(.*)", url).group(1)}, thumb=img, fanart=img, plot=title, isPlayable=True)

    add_item('[B]Поиск[/B]', params={'mode':'search'}, fanart=fanart, icon='DefaultAddonsSearch.png', isFolder=True)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)


def show_releases(params):
    page = int(params.get('p', 1))

    post = {'page':page, 'search':'{"year":"","genre":"","season":""}', 'xpage':'catalog', 'sort':1, 'finish':1}
    if params['mode'] == 'popular':
        post['sort'] = 2

    html = get_html(BASE_URL + '/public/catalog.php', post=post)

    data = json.loads(html)

    if data['err'] != 'ok':
        return

    releases = common.parseDOM(data['table'], 'td')

    if releases:
        for release in releases:

            img = common.parseDOM(release, 'img', attrs={'class':'torrent_pic'}, ret='src')[0]
            title = common.replaceHTMLCodes(common.parseDOM(release, 'span', attrs={'class':'anime_name'})[0])
            desc = common.parseDOM(release, 'span', attrs={'class':'anime_description'})[0]
            number = common.parseDOM(release, 'span', attrs={'class':'anime_number'})[0]
            plot = '[B][COLOR=yellow]%s[/COLOR][/B]\n%s' % (number, common.replaceHTMLCodes(desc))

            url = common.parseDOM(release, 'a', ret='href')[0]
            img = re.sub(r'^/', BASE_URL + '/', img.replace('270x390', '350x500'))

            add_item(title, {'mode':'release', 'u':url}, poster=img, fanart=img, plot=plot, isFolder=True)

    total = int(data['total']) // 12 + 1
    if total > page:
        params['p'] = page + 1
        add_item(u'Далее > %s из %s' % (page + 1, total), params, fanart=fanart, isFolder=True)
    if page > 2:
        add_item('<< В начало', {'mode':'home'}, icon='DefaultFolderBack.png', fanart=fanart)

    xbmcplugin.setContent(handle, 'tvshows')
    xbmcplugin.endOfDirectory(handle)


def show_release(params):
    if params['mode'] == 'play':
        file_id = int(params.get('i', -1))

        if file_id >= 0:
            url = urlparse.unquote_plus(params['u'])

            torrent = get_html(BASE_URL + url)

            temp_name = os.path.join(xbmc.translatePath('special://masterprofile'), 'ani.torrent')

            temp_file = open(temp_name, "wb")
            temp_file.write(torrent)
            temp_file.close()

            uri = 'file:///' + temp_name.replace('\\', '/')

            if addon.getSetting('Engine') == '1': # TAM
                purl ='plugin://plugin.video.tam/?mode=play&url='+ urlparse.quote_plus(temp_name) + '&ind={0}'.format(file_id)
                item = xbmcgui.ListItem(path=purl)
                xbmcplugin.setResolvedUrl(handle, True, item)
                return
            elif addon.getSetting('Engine') == '2': # Elementum
                purl ='plugin://plugin.video.elementum/play?uri='+ urlparse.quote_plus(temp_name) + '&index={0}&oindex={0}'.format(file_id)
                item = xbmcgui.ListItem(path=purl)
                xbmcplugin.setResolvedUrl(handle, True, item)
                return
            else:
                preload_size = int(addon.getSetting('Preload'))

                import player

                if addon.getSetting('Engine') == '3':
                    player.play_ts(handle, preload_size, addon.getSetting('TSHost'), addon.getSetting('TSPort'), torrent, file_id)
                else:
                    player.play_t2h(handle, preload_size, uri, file_id)

            return

    url = urlparse.unquote_plus(params['u'])

    if url == 'rutube' and params['mode'] == 'play':
        rutube_id = urlparse.unquote_plus(params['e'])
        html = get_html('https://rutube.ru/api/play/options/{0}/?no_404=true&referer=https%3A%2F%2Frutube.ru'.format(rutube_id),
                        headers={'Referer':'https://rutube.ru'})
        data = json.loads(html)
        play_episode(data['video_balancer']['m3u8'], data['title'])
        return

    html = get_html(BASE_URL + url)

    title = common.parseDOM(html, 'h1', attrs={'class':'release-title'})

    if title:
        title = title[0]

        img = common.parseDOM(html, 'img', attrs={'id':'adminPoster'}, ret='src')[0]
        img = re.sub(r'^/', BASE_URL + '/', img)

        desc = common.parseDOM(html, 'p', attrs={'class':'detail-description'})[0]

        plot = common.replaceHTMLCodes(desc)
        plot = re.sub(r'<br\s*/*>', '\n', plot)
        plot = plot.replace('<b>', '[B]')
        plot = plot.replace('</b>', '[/B]')
        plot = common.stripTags(plot)
        plot = common.replaceHTMLCodes(plot)
    else:
        title = ''
        plot = ''
        img = icon

    # online
    main_player_exist = False

    try:
        s = re.search(r'file:(\[.*\]), default_quality', html, re.I)
        if s:
            a = s.group(1).replace(r"'", r'"')
            a = a.replace(r'\/', '/')
            a = a.replace('\\http', 'http')

            data = json.loads(a)

            if params['mode'] == 'play':
                e = int(params['e'])
                episode = data[e]

                files = re.findall(r'(?:\[(.+?)\](.+?m3u8))+', episode['file'])

                q = int(addon.getSetting('Quality'))

                for f in files:
                    if f[0] == quality[q]:
                        url = f[1]
                        break
                else:
                    url = files[0][1]

                title = '%s, %s' % (episode['title'], common.replaceHTMLCodes(re.sub(r'<br\s*/*>', ' / ', title)))
                play_episode(url, title)
            else:
                for e, episode in enumerate(data):
                    main_player_exist = True
                    add_item(episode['title'], params={'mode':'play', 'u':url, 'e':e}, plot=plot, fanart=fanart, poster=img, isPlayable=True)
    except:
        pass

    # rutube player
    if not main_player_exist:
        player = common.parseDOM(html, 'div', attrs={'id':'rutubePlayer'})
        if player:
            iframe = common.parseDOM(player, 'div', attrs={'id':'rutubeEpisodes'}, ret='data-episodes')
            if iframe:
                episodes = json.loads(iframe[0])
                for episode in episodes:
                    add_item(f'Серия {episode["ordinal"]}', params={'mode':'play', 'u':'rutube', 'e':episode['rutube_id']}, plot=plot, fanart=fanart, poster=img, isPlayable=True)

    # torrents
    container = common.parseDOM(html, 'div', attrs={'class':'download-torrent'})
    torrents = common.parseDOM(container, 'tr', attrs={'id':'torrentTableID[0-9]*'})
    for torrent in torrents:
        title = common.parseDOM(torrent, 'td', attrs={'class':'torrentcol1'})[0]
        url = common.parseDOM(torrent, 'a', attrs={'class':'torrent-download-link'}, ret='href')[0]
        add_item(title, params={'mode':'torrent', 'u':url}, plot=plot, fanart=fanart, poster=img, isFolder=True)

    # external player
    if addon.getSetting('ShowExternalPlayer') == 'true':
        player = common.parseDOM(html, 'div', attrs={'id':'moonPlayer'})
        iframe = common.parseDOM(player, 'iframe', ret='src')
        if iframe:
            if any(x in iframe[0] for x in ['kodik', 'aniqit']):
                add_item('Внешний плеер', params={'mode':'external', 'u':iframe[0]}, plot=plot, fanart=fanart, poster=img, isFolder=True)

    xbmcplugin.setContent(handle, 'tvshows')
    xbmcplugin.endOfDirectory(handle)


def show_torrent(params):
    url = urlparse.unquote_plus(params['u'])

    torrent_data = get_html(BASE_URL + url)

    import bencode
    torrent = bencode.bdecode(torrent_data)

    series = {}

    try:
        files = torrent['info'].get('files', None)
        if files is None:
            name = '{0} ({1:.0f} MB)'.format(torrent['info']['name'], torrent['info']['length'] / 1024 // 1024)
            add_item(name, {'mode':'play','u':url,'i':0}, icon=icon, fanart=fanart, isPlayable=True, isFolder=False)
        else:
            for i, f in enumerate(files):
                series[i] = '{0} ({1:.0f} MB)'.format(f['path'][-1], f['length'] / 1024 // 1024)

            for i in sorted(series, key=series.get):
                add_item(series[i], {'mode':'play','u':url,'i':i}, icon=icon, fanart=fanart, isPlayable=True, isFolder=False)
            
        xbmcplugin.setContent(handle, 'files')
        xbmcplugin.endOfDirectory(handle)
    except:
        pass


def show_external(params):
    url = re.sub(r'^//', 'https://', urlparse.unquote_plus(params['u']))

    if params['mode'] == 'play_external':

        video_type, video_id, video_hash = url.split('/')
        payload = {'type':video_type, 'id':video_id, 'hash':video_hash}
        html = get_html('https://kodik.info/gvi', post=payload, headers={'Referer':'https://www.anilibria.tv'})
        data = json.loads(html)

        import base64
        purl = base64.standard_b64decode(data['links']['720'][0]['src'][::-1] + '===').decode('utf-8')
        play_episode(purl, params['title'])
        return

    html = get_html(url)

    container = common.parseDOM(html, 'div', attrs={'class':'series-options'})
    series = common.parseDOM(container, 'option')
    ids = common.parseDOM(container, 'option', ret='data-id')
    hashes = common.parseDOM(container, 'option', ret='data-hash')

    if series:
        urls = ['seria/{0}/{1}'.format(id, hash) for id, hash in zip(ids, hashes)]
    else:
        if 'kodik' in url:
            series = ['Фильм']
            urls = ['/'.join(url.split('/')[3:6])]

    for i, name in enumerate(series):
        add_item(name, {'mode':'play_external','u':urls[i], 'title':name.encode('utf-8')}, icon=icon, fanart=fanart, isPlayable=True, isFolder=False)

    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)


def search(params):
    keywords = ''

    kbd = xbmc.Keyboard('', 'Поиск:')
    kbd.doModal()
    if kbd.isConfirmed():
        keywords = kbd.getText()

    if keywords:
        payload = {'search':keywords, 'small':1}

        html = get_html('%s/public/search.php' % BASE_URL, post=payload)
        data = json.loads(html)

        if data['err'] == 'ok':
            releases = common.parseDOM(data['mes'], 'span')
            urls = common.parseDOM(data['mes'], 'a', ret='href')

            for i, release in enumerate(releases):
                if addon.getSetting('ShowDescriptions') == 'true':
                    html = get_html(BASE_URL + urls[i])

                    title = common.parseDOM(html, 'h1', attrs={'class':'release-title'})

                    if title:
                        title = title[0]
                    else:
                        add_item(release, {'mode':'release','u':urls[i], 'title':release.encode('utf-8')}, icon=icon, fanart=fanart, isFolder=True)
                        continue

                    title = common.replaceHTMLCodes(re.sub(r'<br\s*/*>', ' / ', title))

                    img = common.parseDOM(html, 'img', attrs={'id':'adminPoster'}, ret='src')[0]
                    img = re.sub(r'^/', BASE_URL + '/', img)

                    desc = common.parseDOM(html, 'p', attrs={'class':'detail-description'})[0]
                    plot = common.replaceHTMLCodes(desc)
                    plot = re.sub(r'<br\s*/*>', '\n', plot.replace('<b>', '[B]').replace('</b>', '[/B]'))
                    plot = common.stripTags(plot)
                    plot = common.replaceHTMLCodes(plot)

                    add_item(title, {'mode':'release', 'u':urls[i], 'title':title.encode('utf-8')}, plot=plot, fanart=fanart, poster=img, isFolder=True)
                else:
                    add_item(release, {'mode':'release','u':urls[i], 'title':release.encode('utf-8')}, icon=icon, fanart=fanart, isFolder=True)

        xbmcplugin.setContent(handle, 'tvshows')
        xbmcplugin.setPluginCategory(handle, category='Search')
        xbmcplugin.endOfDirectory(handle)


def play_youtube(params):
    purl = 'plugin://plugin.video.youtube/play/?play=1&incognito=true&video_id=' + urlparse.unquote_plus(params['v'])

    item = xbmcgui.ListItem(path=purl)
    xbmcplugin.setResolvedUrl(handle, True, item)


def play_episode(url, title):
    purl = re.sub(r'^//', 'https://', url)

    item = xbmcgui.ListItem(path=purl)
    item.setInfo(type='video', infoLabels={'title':title, 'plot':xbmc.getInfoLabel('ListItem.Plot')})
    if addon.getSetting('UseStreamAdaptive') == 'true':
        item.setProperty('inputstreamaddon', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(handle, True, item)


def add_item(title, params={}, icon='', banner='', fanart='', poster='', thumb='', plot='', isFolder=False, isPlayable=False, url=None):
    item = xbmcgui.ListItem(title)
    item.setInfo(type='video', infoLabels={'title':title, 'plot':plot})

    if isPlayable:
        item.setProperty('isPlayable', 'true')
        item.setProperty('mediatype', 'video')
    
    if icon != '':
        item.setArt({'icon': icon})
    if banner != '':
        item.setArt({'banner':banner})
    if fanart != '':
        item.setArt({'fanart':fanart})
    if poster != '':
        item.setArt({'poster':poster})
    if thumb != '':
        item.setArt({'thumb':thumb})

    if url is None:
        url = '%s?%s' % (sys.argv[0], urlparse.urlencode(params))
        item.setContentLookup(False)

    xbmcplugin.addDirectoryItem(handle, url=url, listitem=item, isFolder=isFolder)


params = common.getParameters(sys.argv[2])

mode = params.get('mode', '')

if mode == '':
    main_menu()

elif mode in ['new', 'popular']:
    show_releases(params)

elif mode == 'search':
    search(params)

elif mode == 'home':
    xbmc.executebuiltin('Container.Update({}, replace)'.format(sys.argv[0]))
    xbmcplugin.endOfDirectory(handle, True, True)

elif mode in ['release', 'play']:
    show_release(params)

elif mode in ['external', 'play_external']:
    show_external(params)

elif mode == 'youtube':
    play_youtube(params)

elif mode == 'torrent':
    show_torrent(params)

elif mode == 'cleancache':
    from tccleaner import TextureCacheCleaner as tcc
    tcc().remove_like('%anilibria%', True)
