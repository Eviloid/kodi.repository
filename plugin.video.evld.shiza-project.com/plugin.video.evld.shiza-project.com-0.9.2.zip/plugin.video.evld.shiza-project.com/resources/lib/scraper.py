# -*- coding: utf-8 -*-

import re, json

from urllib2 import HTTPError

import api
import utils

BASE_URL = 'https://shiza-project.com'
BASE_API_URL = BASE_URL + '/graphql'


class ScraperException(Exception):
    pass

class ShizaScraper():
    def __init__(self, after=None, query=None, hide_online=True):
        self._hide_online = hide_online
        self._after = after
        self._query = query
        self._total_page = 0

        self._json = None

    @property
    def after(self):
        return self._after

    @property
    def total_page(self):
        return self._total_page
    
    @classmethod
    def fetch(self, url, params={}, post={}, headers={}):
        return utils.get_html(url, params, post, headers)

    def check_auth(self):
        return True

    def login(self, login, password):
        pass

    def _check_pagination(self):
        data = self._json['data'].get('releases', self._json['data'].get('collections'))
        page_info = data['pageInfo']

        self._total_page = data.get('totalCount', 0) / api.ITEMS_PER_PAGE + 1

        if page_info['hasNextPage']:
            self._after = page_info['endCursor']
        else:
            self._after = ''


    def _parse_collections(self):
        items = []

        releases = self._json['data']['collections']

        for release in releases['edges']:
            node = release['node']
            title = node['name']
            plot = node['content']

            img = node['previewItems'][0]['collectionable']['posters'][0]['preview']['url']
            url = node['slug']
            items.append({'title':title, 'url':url, 'img':img, 'plot':plot})

        return items

    
    def _parse_releases(self):
        items = []

        releases = self._json['data']['releases']

        for release in releases['edges']:
            node = release['node']
            title = node['name']

            announcement = ''

            if node['announcement']:
                announcement = node['announcement']
            elif node['episodesAired']:
                announcement = u'Добавлена {:02d} серия'.format(node['episodesAired'])
            
            original = node['originalName']
            genres = api.get_genres(node['genres'])

            plot = u'[COLOR yellow]{0}[/COLOR]\n\n[COLOR gray]{1}[/COLOR]'.format(announcement, original)
            if genres:
                plot = u'{0}\n\nЖанры: [COLOR ff137ddc]{1}[/COLOR]'.format(plot, genres)

            if node['season']:
                plot = u'{0}\n\nСезон: [COLOR ff137ddc]{1}[/COLOR]'.format(plot, api.get_season(node))

            id = node['id']
            img = node['posters'][0]['preview']['url']
            url = node['slug']
            items.append({'title':title, 'url':url, 'img':img, 'plot':plot, 'id':id})

        return items


    def _parse_release(self):
        items = []

        release = self._json['data']['release']

        plot = utils.clean_text(release['description'])
        mpaa = release.get('rating', '')
        if mpaa:
            plot = u'[B][COLOR yellow]{0}[/COLOR][/B] {1}'.format(api.mpaa_rus(mpaa), plot)

        fanart = release['cover']['original']['url'] if release['cover'] else ''
        img = release['posters'][0]['preview']['url']

        items.append({'title':'Описание', 'img':img, 'fanart':fanart, 'plot':plot, 'type':'info'})

        # online
        if not self._hide_online:

            # trailer
            if release['videos']:
                data = utils.parse_online_videos([v['embedUrl'] for v in release['videos']])
                if data:
                    url = data['url']
                    thumb = data['thumb']
                    video = data['embed']

                    if url[:4] == 'http':
                        items.append({'title':'Трейлер', 'thumb':thumb, 'fanart':fanart, 'url':video, 'type':'online'})

            for episode in release['episodes']:
                title = u'{0}. {1}'.format(episode["number"], episode["name"])

                if episode['videos']:
                    data = utils.parse_online_videos([v['embedUrl'] for v in episode['videos']])
                    if not data:
                        continue

                    url = data['url']
                    thumb = data['thumb']
                    video = data['embed']

                    if url[:4] == 'http':
                        items.append({'title':title, 'thumb':thumb, 'fanart':fanart, 'url':video, 'type':'online'})
                    else:
                        title = u'[COLOR red]{}[/COLOR]'.format(title)
                        url = u'[COLOR red]{}[/COLOR]'.format(url)
                        items.append({'title':title, 'thumb':img, 'fanart':fanart, 'plot':url, 'type':'offline'})

        # torrents
        for torrent in release['torrents']:
            title = torrent['synopsis'] if torrent['synopsis'] else '{0} {1}'.format(torrent['videoFormat'], torrent['videoQualities'][0])
            title = u'{0} ({1:.2f} GB)'.format(title, float(torrent['size']) / 1024 / 1024 / 1024)
            plot = u'Seeders: {0}\n\n{1}'.format(torrent['seeders'], torrent['metadata'])
            items.append({'title':title, 'img':img, 'fanart':fanart, 'plot':plot, 'id':torrent['id'], 'type':'torrent'})

        return items


    def get_torrent(self, torrent_id):
        return ShizaScraper.fetch('{0}/torrents/{1}/download'.format(BASE_URL, torrent_id))

    def get_torrent_items(self, torrent_id):

        torrent_data = self.get_torrent(torrent_id)

        data = utils.bdecode(torrent_data)

        items = []

        files = data['info'].get('files', None)

        if files == None:
            title = u'{0} ({1} MB)'.format(data['info']['name'], data['info']['length'] / 1024 / 1024)
            items.append({'title':title, 'id':0})
        else:
            for i, f in enumerate(files):
                title = u'{0} ({1} MB)'.format(f['path'][-1].decode('utf-8'), f['length'] / 1024 / 1024)
                items.append({'title':title, 'id':i})
            items = sorted(items, key=lambda x: x['title'])

        return items

    def get_all(self):
        query = api.get_all_query(self.after, self._query)
        answer = ShizaScraper.fetch(BASE_API_URL, post=query)
        self._json = json.loads(answer)
        self._check_pagination()
        return self._parse_releases()

    def get_ongoing(self):
        query = api.get_ongoing_query(self.after)
        answer = ShizaScraper.fetch(BASE_API_URL, post=query)
        self._json = json.loads(answer)
        self._check_pagination()
        return self._parse_releases()


    def get_workin(self):
        query = api.get_workin_query(self.after)
        answer = ShizaScraper.fetch(BASE_API_URL, post=query)
        self._json = json.loads(answer)
        self._check_pagination()
        return self._parse_releases()


    def get_completed(self):
        query = api.get_completed_query(self.after)
        answer = ShizaScraper.fetch(BASE_API_URL, post=query)
        self._json = json.loads(answer)
        self._check_pagination()
        return self._parse_releases()


    def get_collections(self):
        query = api.get_collections_query()
        answer = ShizaScraper.fetch(BASE_API_URL, post=query)
        self._json = json.loads(answer)
        self._check_pagination()
        return self._parse_collections()


    def get_favorite(self):
        return []


    def get_release(self, id):
        query = api.get_release_query(id)
        answer = ShizaScraper.fetch(BASE_API_URL, post=query)
        self._json = json.loads(answer)
        return self._parse_release()
