# SHIZA Project video addon
Дополнение Kodi для просмотра аниме от команды [Shiza Project](http://shiza-project.com)

#### Основное меню
![Основное меню дополнения](https://github.com/Eviloid/kodi.repository/raw/master/plugin.video.evld.shiza-project.com/screens/scr1.jpg)

#### Релизы
![Список релизов](https://github.com/Eviloid/kodi.repository/raw/master/plugin.video.evld.shiza-project.com/screens/scr2.jpg)

#### Серии
![Список серий для просмотра](https://github.com/Eviloid/kodi.repository/raw/master/plugin.video.evld.shiza-project.com/screens/scr3.jpg)

#### Избранное
![Избранное](https://github.com/Eviloid/kodi.repository/raw/master/plugin.video.evld.shiza-project.com/screens/scr4.jpg)
