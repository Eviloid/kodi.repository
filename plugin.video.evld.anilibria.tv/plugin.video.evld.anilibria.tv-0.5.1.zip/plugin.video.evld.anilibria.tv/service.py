import xbmc, xbmcaddon
import threading
import SimpleHTTPServer
import SocketServer
import urllib2


class Main:
    def __init__(self):
        try:
            httpd = SocketServer.TCPServer(('localhost', 8008), WebHandler)
            kodi_waiter = threading.Thread(target=self.kodi_waiter_thread, args=(httpd, ))
            kodi_waiter.start()
            httpd.serve_forever()
        except:
            pass

    @staticmethod
    def kodi_waiter_thread(httpd):
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            if monitor.waitForAbort(3):
                break
        httpd.shutdown()

class WebHandler(SimpleHTTPServer.SimpleHTTPRequestHandler):
    def do_GET(self):

        result = 503

        try:
            data = WebHandler.get_html(self.path[1:])
            result = 200
        except urllib2.HTTPError, err:
            result = err.code
        except:
            pass

        self.send_response(result)
        self.end_headers()

        if result == 200:
            self.wfile.write(data)

    def do_HEAD(self):
        self.send_response(200)
        self.end_headers()

    # next methods were added to minimize number of messages printed to log
    # because Kodi closes socket connection on error code
    def handle_one_request(self):
        try:
            SimpleHTTPServer.SimpleHTTPRequestHandler.handle_one_request(self)
        except IOError:
            pass  # it's OK

    def finish(self):
        try:
            SimpleHTTPServer.SimpleHTTPRequestHandler.finish(self)  # super.finish()
        except IOError:
            pass  # it's OK

    def log_request(self, code='-', size='-'):
        if code != 200:
            SimpleHTTPServer.SimpleHTTPRequestHandler.log_request(self, code, size)


    @staticmethod
    def get_html(url, headers = {}):
    
        headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0'

        addon = xbmcaddon.Addon(id='plugin.video.evld.anilibria.tv')
        proxy = addon.getSetting('Proxy')

        ph = urllib2.ProxyHandler({'https':proxy, 'http':proxy})
        opener = urllib2.build_opener(ph)

        conn = opener.open(urllib2.Request(url, headers=headers))

        html = conn.read()
        conn.close()

        return html


if __name__ == "__main__":
    Main()