#!/usr/bin/python
# -*- coding: utf-8 -*-


# usage:
#    import player
#    player.xPlay(uri, file_id)


import xbmc, xbmcgui, xbmcplugin
import sys, os

class xPlayer(xbmc.Player):
    from torrent2http import MediaType

    def __init__(self):
        self.tsserv = None
        self.active = True
        self.started = False
        self.ended = False
        self.paused = False
        self.buffering = False

        self.engine = None

        xbmc.Player.__init__(self)
        width, height = xPlayer.get_skin_resolution()
        w = width
        h = int(0.14 * height)
        x = 0
        y = (height - h) / 2
        self._ov_window = xbmcgui.Window(12005)
        self._ov_label = xbmcgui.ControlLabel(x, y, w, h, '', alignment=6)
        self._ov_background = xbmcgui.ControlImage(x, y, w, h, xPlayer.get_ov_image())
        self._ov_background.setColorDiffuse('0xD0000000')

        self.ov_visible = False
        self.onPlayBackStarted()


    def onPlayBackPaused(self):
        self.ov_show()


    def get_status(self):
        try:
            status   = self.engine.status()
            speed    = status.download_rate / 1024 * 8
            seeds    = status.num_seeds
        except:
            speed    = '?????'
            seeds    = '?'
        
        try:    tdownload = status.total_download / 1024 / 1024
        except: tdownload = '???'
        
        try:
            files = self.engine.list(media_types=[MediaType.VIDEO])
            file_id = files[0].index
            file_status = self.engine.file_status(file_id)
            download = file_status.download / 1024 / 1024
        except:
            download = tdownload

        return "Загружено [B]"+str(download)+"[/B] MB \nСиды: [B]"+str(seeds)+"[/B] \nСкорость: [B]"+str(speed)[:4]+'[/B] Mbit/s'


    def onPlayBackStarted(self):
        self.ov_hide()
        if not xbmc.Player().isPlaying(): xbmc.sleep(2000)
        status = ''
        while xbmc.Player().isPlaying():
            if self.ov_visible == True:
                status = self.get_status()
                self.ov_update(status)
            xbmc.sleep(800)


    def onPlayBackResumed(self):
        self.ov_hide()
        
    def onPlayBackStopped(self):
        self.ov_hide()
    
    def __del__(self):
        self.ov_hide()

    @staticmethod
    def get_ov_image():
        import base64
        ov_image = os.path.join(xbmc.translatePath('special://masterprofile'), 'bg.png')
        if not os.path.isfile(ov_image):
            fl = open(ov_image, 'wb')
            fl.write(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII='))
            fl.close()
        return ov_image

    @staticmethod
    def get_skin_resolution():
        import xml.etree.ElementTree as Et
        skin_path = xbmc.translatePath('special://skin/')
        tree = Et.parse(os.path.join(skin_path, 'addon.xml'))
        res = tree.findall('./extension/res')[0]
        return int(res.attrib['width']), int(res.attrib['height'])

    def ov_show(self):
        if not self.ov_visible:
            self._ov_window.addControls([self._ov_background, self._ov_label])
            self.ov_visible = True

    def ov_hide(self):
        if self.ov_visible:
            self._ov_window.removeControls([self._ov_background, self._ov_label])
            self.ov_visible = False

    def ov_update(self, txt=" "):
        if self.ov_visible:
            self._ov_label.setLabel(txt)


def xPlay(uri, file_id=None, DDir=None):
    from torrent2http import State, Engine, MediaType
    progressBar = xbmcgui.DialogProgress()
    from contextlib import closing

    DDir = DDir if DDir else xbmc.translatePath('special://masterprofile')

    progressBar.create('Torrent2Http', 'Запуск')
    # XBMC addon handle
    # handle = ...
    # Playable list item
    # listitem = ...
    # We can     know file_id of needed video file on this step, if no, we'll try to detect one.
    # file_id = None
    # Flag will set to True when engine is ready to resolve URL to XBMC
    ready = False
    # Set pre-buffer size to 15Mb. This is a size of file that need to be downloaded before we resolve URL to XMBC 
    pre_buffer_bytes = 15 * 1024 * 1024
    
    engine = Engine(uri, download_path=DDir, trackers=['udp://tracker.leechers-paradise.org:6969/announce'])

    with closing(engine):
        # Start engine and instruct torrent2http to begin download first file, 
        # so it can start searching and connecting to peers  
        engine.start(file_id)
        progressBar.update(0, 'Torrent2Http', 'Загрузка торрента', "")
        while not xbmc.abortRequested and not ready:
            xbmc.sleep(500)

            if progressBar.iscanceled():
                ready = False
                break

            status = engine.status()
            # Check if there is loading torrent error and raise exception 
            engine.check_torrent_error(status)
            # Trying to detect file_id
            if file_id is None:
                # Get torrent files list, filtered by video file type only
                files = engine.list(media_types=[MediaType.VIDEO])
                # If torrent metadata is not loaded yet then continue
                if files is None:
                    continue
                # Torrent has no video files
                if not files:
                    progressBar.close()
                    break
                # Select first matching file                    
                file_id = files[0].index
                file_status = files[0]
            else:
                # If we've got file_id already, get file status
                file_status = engine.file_status(file_id)
                # If torrent metadata is not loaded yet then continue
                if not file_status:
                    continue
            if status.state == State.DOWNLOADING:
                # Wait until minimum pre_buffer_bytes downloaded before we resolve URL to XBMC
                if file_status.download >= pre_buffer_bytes:
                    ready = True
                    break
                #print file_status
                #downloadedSize = status.total_download / 1024 / 1024
                getDownloadRate = status.download_rate / 1024 * 8
                #getUploadRate = status.upload_rate / 1024 * 8
                getSeeds = status.num_seeds
                
                progressBar.update(100 * file_status.download / pre_buffer_bytes, 'Предварительная буферизация: ' + str(file_status.download / 1024 / 1024) + " MB", "Сиды: " + str(getSeeds), "Скорость: " + str(getDownloadRate)[:4] + ' Mbit/s')
                
            elif status.state in [State.FINISHED, State.SEEDING]:
                #progressBar.update(0, 'T2Http', 'We have already downloaded file', "")
                # We have already downloaded file
                ready = True
                break
            
            # Here you can update pre-buffer progress dialog, for example.
            # Note that State.CHECKING also need waiting until fully finished, so it better to use resume_file option
            # for engine to avoid CHECKING state if possible.
            # ...
        progressBar.update(0)
        progressBar.close()
        if ready:
            Player=xPlayer()
            Player.engine = engine

            # Resolve URL to XBMC
            item = xbmcgui.ListItem(path=file_status.url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            xbmc.sleep(3000)
            # Wait until playing finished or abort requested
            while not xbmc.abortRequested and xbmc.Player().isPlaying():
                xbmc.sleep(500)
