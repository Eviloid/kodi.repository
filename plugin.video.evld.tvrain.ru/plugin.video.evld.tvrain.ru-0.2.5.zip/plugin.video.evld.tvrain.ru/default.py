# -*- coding: utf-8 -*-

import os, sys, re, json
import urllib, urllib2
import datetime, time

import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import CommonFunctions


#fix for datatetime.strptime returns None
class proxydt(datetime.datetime):
    def __init__(self, *args, **kwargs):
        super(proxydt, self).__init__(*args, **kwargs)

    @classmethod
    def strptime(cls, date_string, format):
        return datetime(*(time.strptime(date_string, format)[0:6]))

datetime.datetime = proxydt
from datetime import datetime


try:handle = int(sys.argv[1])
except:pass

addon = xbmcaddon.Addon(id='plugin.video.evld.tvrain.ru')

Pdir = addon.getAddonInfo('path')
main_icon = xbmc.translatePath(os.path.join(Pdir, 'icon.png'))
main_fanart = xbmc.translatePath(os.path.join(Pdir, 'fanart.jpg'))

xbmcplugin.setContent(handle, 'videos')

common = CommonFunctions
common.plugin = addon.getAddonInfo('name')


def_headers = {'Accept'                       : 'application/tvrain.api.2.13+json',
                'Accept-Language'              : 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
                'Accept-Encoding'              : 'gzip, deflate',
                'X-User-Agent'                 : 'TV Client (Browser); API_CONSUMER_KEY=a908545f-80af-4f99-8dac-fb012cec',
                'X-Result-Define-Thumb-Width'  : '512',
                'X-Result-Define-Thumb-height' : '280',
                'X-Result-Define-Video-Only-Flag': '1',
                'Referer'                      : 'http://smarttv.tvrain.ru/',
                'Origin'                       : 'http://smarttv.tvrain.ru',
                'Connection'                   : 'keep-alive',
            }


def get_html(url, params=None, post=None, headers={}):
    if params:
        url = '%s?%s' % (url, urllib.urlencode(params))

    if post:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
        request = urllib2.Request(url, urllib.urlencode(post))
    else:
        request = urllib2.Request(url)

    for key, val in def_headers.items():
        request.add_header(key, val)

    for key, val in headers.items():
        request.add_header(key, val)

    conn = urllib2.urlopen(request)
    html = conn.read()

    if conn.headers.get('Content-Encoding', '') == 'gzip':
        import zlib
        html = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(html)

    conn.close()

    return html


def add_item(title, params={}, icon=None, banner=None, fanart=None, poster=None, thumb=None, plot=None, isFolder=True, isPlayable=False, url=None):
    item = xbmcgui.ListItem(title, iconImage=icon, thumbnailImage=thumb)

    il = {'title': title, 'plot': plot}

    if params.get('mode') == 'live':
        il['watched'] = 'false'

    item.setInfo(type='Video', infoLabels=il)

    if isPlayable:
        item.setProperty('mediatype', 'video')
        item.setProperty('isPlayable', 'true')

    fanart = fanart or main_fanart
    
    if banner:
        item.setArt({'banner': banner})
    if fanart:
        item.setArt({'fanart': fanart})
    if poster:
        item.setArt({'poster': poster})
    if thumb:
        item.setArt({'thumb': thumb})

    if url is None:
        url = '%s?%s' % (sys.argv[0], urllib.urlencode(params))
        item.setContentLookup(False)

    xbmcplugin.addDirectoryItem(handle, url=url, listitem=item, isFolder=isFolder)


def main_menu():
    add_item('[B]Эфир[/B]', {'mode':'live'}, icon=main_icon, isPlayable=True, isFolder=False)
    add_item('Популярное', {'mode':'popular'})
    add_item('Наш Выбор', {'mode':'ourchoice'})
    add_item('Программы', {'mode':'programs'})
    add_item('Всё видео', {'mode':'all'})
    add_item('Поиск', {'mode':'search'}, icon='DefaultAddonsSearch.png')

    xbmcplugin.endOfDirectory(handle)


def live():
    quality = addon.getSetting('LiveQuality')

    if quality == 'Авто (mpd)':
        purl = 'https://strm.yandex.ru/kal/tvrain2/manifest.mpd'
    else:
        html = get_html('https://api.tvrain.ru/api_v2/live/')
        data = json.loads(html)

        quality = 'Автоматическое определение качества' if quality == 'Авто (hls)' else quality

        for i in data['HLS_SMARTTV_TEST']:
            if i['label'].encode('utf-8') == quality:
                purl = i['url']

    item = xbmcgui.ListItem(path=purl)
    item.setInfo(type='video', infoLabels={'title':'Live'})
    item.setProperty('inputstreamaddon', 'inputstream.adaptive')

    if '.mpd' in purl:
        item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        item.setProperty('inputstream.adaptive.license_key', 'https://cwip-shaka-proxy.appspot.com/no_auth||R{SSM}|')
    
        item.setMimeType('application/dash+xml')
        item.setContentLookup(False)
    else:
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')

    xbmcplugin.setResolvedUrl(handle, True, item)


def play(params):
    html = get_html('https://api.tvrain.ru/api_v2/articles/%s/auto/' % params['id'])
    data = json.loads(html)

    if len(data) > 0:
        item = xbmcgui.ListItem(path=data[0]['auto']['data'])
        item.setInfo(type='video', infoLabels={})
        item.setProperty('inputstreamaddon', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        xbmcplugin.setResolvedUrl(handle, True, item)


def show_articles(data):
    for i in data:
        plot = i['name'].encode('utf-8')
        title = ('[Full] ' if i['is_full'] == 1 else '') + plot

        date_string = i['date_active_start'].encode('utf-8')[0:23]
        dt = datetime.strptime(date_string, '%a, %d %b %y %H:%M:%S')   #Fri, 28 Feb 20 11:53:44 +0300

        plot = '[B]%s[/B]\n%s' % (dt.strftime('%d/%m/%Y'), plot)

        add_item(title, {'mode':'play', 'id':i['id']}, thumb=i['preview_img'], plot=plot, isPlayable=True, isFolder=False)


def popular(params):
    period = params.get('period')

    if period:
        html = get_html('https://api.tvrain.ru/api_v2/widgets/popular/', headers={'X-Result-Define-Period':'%s' % period})
        data = json.loads(html)

        show_articles(data['elements'])
    else:
        add_item('За неделю',     {'mode':'popular','period':'1w'})
        add_item('За месяц',      {'mode':'popular','period':'1m'})
        add_item('За три месяца', {'mode':'popular','period':'3m'})
        add_item('За полгода',    {'mode':'popular','period':'6m'})
        add_item('За год',        {'mode':'popular','period':'12m'})
        add_item('За всё время',  {'mode':'popular','period':'forever'})

    xbmcplugin.endOfDirectory(handle)


def ourchoice(params):
    html = get_html('https://api.tvrain.ru/api_v2/widgets/ourchoice/')
    data = json.loads(html)

    show_articles(data)
    
    xbmcplugin.endOfDirectory(handle)


def programs(params):
    cid = params.get('cid')

    if cid is None:
        html = get_html('https://api.tvrain.ru/api_v2/programs/categories/')
        data = json.loads(html)

        add_item('Популярные программы', {'mode':'programs', 'cid':'cool'})
        for i in data['elements']:
            add_item(data['elements'][i].encode('utf-8'), {'mode':'programs', 'cid':i})
    else:
        html = get_html('https://api.tvrain.ru/api_v2/programs/', headers={'X-Result-Define-Pagination':'1/250'})
        data = json.loads(html)

        if cid == 'cool':
            field_name ='is_cool'
            value = '1'
        else:
            field_name = 'category_id'
            value = cid

        for i in data['elements']:
            if str(i[field_name]) == value:
                add_item(i['name'].encode('utf-8'), {'mode':'program', 'id':i['id']}, thumb=i['preview_img'], plot=i['name'].encode('utf-8'))

    xbmcplugin.endOfDirectory(handle)


def program(params):
    page = params.get('page', '1')

    html = get_html('https://api.tvrain.ru/api_v2/programs/%s/articles/' % params['id'], headers={'X-Result-Define-Pagination':'%s/20' % page})
    data = json.loads(html)

    current_page = data['current_page']
    total_pages  = data['total_pages']

    show_articles(data['elements'])

    if current_page < total_pages:
        title = 'Далее > %d из %d' % (current_page + 1, total_pages)
        params.update({'page':current_page + 1})
        add_item(title, params)

    xbmcplugin.endOfDirectory(handle)


def show_videos(params, html):
    pagination = common.parseDOM(html, 'div', {'class':'pagination'})
    pagination = common.parseDOM(pagination, 'a')
    total = int(pagination[-1]) if pagination else 0

    page = int(params.get('p', 1))

    videos = common.parseDOM(html, 'div', {'class':'chrono_list__item'})

    for video in videos:

        title = common.parseDOM(video, 'a', {'class':'chrono_list__item__info__name .*?'})[0]
        title = common.replaceHTMLCodes(title)
        img = common.parseDOM(video, 'img', {'class':'chrono_list__item__image__bg'}, ret='src')
        img = ('https://' + img[0]) if img else None

        id = common.parseDOM(video, 'div', {'tooltip':u'Смотреть позже'}, ret='data-watchlater-id')
        if id:
            label = common.parseDOM(video, 'a', {'class':'article__info__label .*?'})
            label = '[B][COLOR=FFCF3476]%s[/COLOR][/B]\n' % label[0] if label else ''

            plot = common.parseDOM(video, 'div', {'class':'meta__value'})[0]
            plot = '[B]%s[/B]\n%s' % (common.stripTags(plot), title)
            plot = label + plot

            add_item(title, {'mode':'play','id':id[0]}, thumb=img, plot=plot, isPlayable=True, isFolder=False)

    if page < total:
        params['p'] = page + 1
        add_item(u'Далее > %s из %s' % (page + 1, total), params)


def all_video(params):
    page = int(params.get('p', 1))

    html = get_html('http://tvrain.ru/archive/', {'page':page, 'tab':1})
    show_videos(params, html)

    xbmcplugin.endOfDirectory(handle)


def search(params):
    page = int(params.get('p', 1))

    keywords = urllib.unquote_plus(params.get('q', ''))

    if not keywords:
        kbd = xbmc.Keyboard('', 'Поиск:')
        kbd.doModal()
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        if kbd.isConfirmed():
            keywords = kbd.getText()
            if keywords:
                xbmc.executebuiltin('Container.Update(%s?mode=search&q=%s, replace)' % (sys.argv[0], urllib.quote_plus(keywords)))
                return
        xbmc.executebuiltin('Container.Update(%s, replace)' % sys.argv[0])

    else:
        html = get_html('http://tvrain.ru/archive/', {'query':keywords, 'page':page, 'tab':1})
        show_videos(params, html)

        xbmcplugin.endOfDirectory(handle)


if addon.getSetting('IsAuthorized') == 'true':
    def_headers['Authorization'] = addon.getSetting('Authorization')


params = common.getParameters(sys.argv[2])

mode = params['mode'] = params.get('mode', '')

if mode == '':
    main_menu()

elif mode == 'live':
    live()

elif mode == 'play':
    play(params)

elif mode == 'ourchoice':
    ourchoice(params)

elif mode == 'programs':
    programs(params)

elif mode == 'program':
    program(params)

elif mode == 'popular':
    popular(params)

elif mode == 'all':
    all_video(params)

elif mode == 'search':
    search(params)

elif mode == 'login':
    user = addon.getSetting('User')
    password = addon.getSetting('Password')

    html = get_html('https://api.tvrain.ru/api_v2/user/auth/', post={'email':user, 'passw':password})
    data = json.loads(html)

    if 'device_token' in data:
        import base64
        addon.setSetting('Authorization','Basic ' + base64.b64encode(str(data['user_id']) + ':' + str(data['device_token'])))
        addon.setSetting('IsAuthorized', 'true')

    addon.openSettings()

elif mode == 'logout':
    addon.setSetting('Authorization','')
    addon.setSetting('IsAuthorized', 'false')
    xbmc.executebuiltin('SendClick(10)', True)

elif mode == 'cleancache':
    from tccleaner import TextureCacheCleaner as tcc
    tcc().remove_like('%cdn.ngenix.net%', True)
