# FanSerials video addon
Дополнение Kodi для просмотра сериалов с сайта [FanSerials.tv](http://fanserials.tv)
